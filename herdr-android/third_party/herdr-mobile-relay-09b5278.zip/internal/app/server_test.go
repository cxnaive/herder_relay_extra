package app

import (
	"bufio"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync/atomic"
	"syscall"
	"testing"
	"time"

	"github.com/0cv/herdr-mobile-relay/internal/activity"
	"github.com/0cv/herdr-mobile-relay/internal/agentroots"
	"github.com/0cv/herdr-mobile-relay/internal/config"
	"github.com/0cv/herdr-mobile-relay/internal/conversation"
	"github.com/0cv/herdr-mobile-relay/internal/coordinator"
	"github.com/0cv/herdr-mobile-relay/internal/copyresponse"
	"github.com/0cv/herdr-mobile-relay/internal/deviceauth"
	"github.com/0cv/herdr-mobile-relay/internal/herdr"
	"github.com/0cv/herdr-mobile-relay/internal/panedelta"
	"github.com/0cv/herdr-mobile-relay/internal/protocol"
	"github.com/0cv/herdr-mobile-relay/internal/push"
	"github.com/0cv/herdr-mobile-relay/internal/question"
	"github.com/0cv/herdr-mobile-relay/internal/session"
	"github.com/0cv/herdr-mobile-relay/internal/slashcmd"
	"github.com/0cv/herdr-mobile-relay/internal/speech"
	"github.com/0cv/herdr-mobile-relay/internal/transport"
	"github.com/coder/websocket"
)

func testServer() *Server {
	return testServerWithCacheDir("")
}

func testServerWithCacheDir(cacheDir string) *Server {
	cfg := &config.Config{
		Host:       "127.0.0.1",
		Port:       8375,
		InstanceID: "test-instance",
		CacheDir:   cacheDir,
	}
	return New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
}

func publishInventoryForTest(t *testing.T, server *Server) {
	t.Helper()
	if err := server.publishCurrentInventory(context.Background()); err != nil {
		t.Fatal(err)
	}
}
func TestAuthorizeAuthenticatedIdentity(t *testing.T) {
	mutation := protocol.ActionMetadata{Operation: "send_input", Class: protocol.ActionMutating}
	filter := protocol.ActionMetadata{Operation: "send_filter_text", Class: protocol.ActionMutating}
	read := protocol.ActionMetadata{Operation: "read_pane", Class: protocol.ActionReadOnly}

	for _, test := range []struct {
		name          string
		identity      transport.AuthenticatedIdentity
		authenticated bool
		action        protocol.ActionMetadata
		deviceID      string
		wantDenied    bool
	}{
		{name: "reader mutation", identity: transport.AuthenticatedIdentity{Role: string(protocol.RoleReader)}, authenticated: true, action: mutation, wantDenied: true},
		{name: "reader read", identity: transport.AuthenticatedIdentity{Role: string(protocol.RoleReader)}, authenticated: true, action: read},
		{name: "reader filter denied", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleReader)}, authenticated: true, action: filter, wantDenied: true},
		{name: "controller filter allowed", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleController)}, authenticated: true, action: filter},
		{name: "reader self revoke", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleReader)}, authenticated: true, action: protocol.ActionMetadata{Operation: "revoke_device", Class: protocol.ActionMutating}, deviceID: "device-current"},
		{name: "reader other revoke", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleReader)}, authenticated: true, action: protocol.ActionMetadata{Operation: "revoke_device", Class: protocol.ActionMutating}, deviceID: "device-other", wantDenied: true},
		{name: "controller mutation", identity: transport.AuthenticatedIdentity{Role: string(protocol.RoleController)}, authenticated: true, action: mutation},
		{name: "local connection", action: mutation},
		{name: "unauthenticated push subscribe", action: protocol.ActionMetadata{Operation: "push_subscribe", Class: protocol.ActionMutating}, wantDenied: true},
		{name: "reader own-device push policy", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleReader)}, authenticated: true, action: protocol.ActionMetadata{Operation: "push_policy_set", Class: protocol.ActionMutating}, deviceID: "spoofed-other"},
		{name: "unauthenticated push open", action: protocol.ActionMetadata{Operation: "push_open_ref", Class: protocol.ActionReadOnly}, wantDenied: true},
		{name: "reader push test", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleReader)}, authenticated: true, action: protocol.ActionMetadata{Operation: "push_test_device", Class: protocol.ActionMutating}},
		{name: "unauthenticated push test", action: protocol.ActionMetadata{Operation: "push_test_device", Class: protocol.ActionMutating}, wantDenied: true},
		{name: "controller push test", identity: transport.AuthenticatedIdentity{DeviceID: "device-current", Role: string(protocol.RoleController)}, authenticated: true, action: protocol.ActionMetadata{Operation: "push_test_device", Class: protocol.ActionMutating}},
	} {
		t.Run(test.name, func(t *testing.T) {
			err := authorizeAuthenticatedIdentity(test.identity, test.authenticated, test.action, test.deviceID)
			if (err != nil) != test.wantDenied {
				t.Fatalf("authorizeAuthenticatedIdentity() error = %#v, want denied %v", err, test.wantDenied)
			}
			if err != nil && (err.Code != protocol.ErrorReaderDenied || err.Args["operation"] != test.action.Operation) {
				t.Fatalf("authorizeAuthenticatedIdentity() error = %#v", err)
			}
		})
	}
}

func TestReservePushTestThrottlesPerDevice(t *testing.T) {
	server := testServer()
	now := time.Date(2026, time.September, 2, 12, 0, 0, 0, time.UTC)
	if !server.reservePushTest("device-1", now) {
		t.Fatal("first push test was throttled")
	}
	if server.reservePushTest("device-1", now.Add(pushTestInterval-time.Millisecond)) {
		t.Fatal("repeated push test inside interval was accepted")
	}
	if !server.reservePushTest("device-2", now.Add(time.Second)) {
		t.Fatal("one device throttled another device")
	}
	if !server.reservePushTest("device-1", now.Add(pushTestInterval)) {
		t.Fatal("push test remained throttled after interval")
	}
	// Nothing older than one interval can throttle anything, so stale rows are
	// dropped rather than accumulating one timestamp per device that ever asked
	// for a test.
	if !server.reservePushTest("device-3", now.Add(time.Hour)) {
		t.Fatal("later push test was throttled")
	}
	if len(server.pushTestLast) != 1 {
		t.Fatalf("push test throttle retained %d devices, want 1", len(server.pushTestLast))
	}
	// A revoked device leaves no throttle behind for the next enrolment.
	server.forgetPushTest("device-3")
	if !server.reservePushTest("device-3", now.Add(time.Hour)) {
		t.Fatal("re-enrolled device inherited the revoked device's throttle")
	}
}

func TestValidateExactPaneTargetBindsCurrentTerminalGenerationAndAgentSession(t *testing.T) {
	server := testServer()
	server.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", ServerSessionID: "primary", TerminalID: "terminal-1",
		Generation: 4, SessionID: "agent-session-1",
	}}, server.state.RevisionCounter())
	current, ok := server.state.Agent("pane-1")
	if !ok {
		t.Fatal("committed agent missing")
	}
	exact := protocol.TargetRef{
		ServerSessionID: current.ServerSessionID, PaneID: current.PaneID, TerminalID: current.TerminalID,
		Generation: current.Generation, AgentSessionID: current.SessionID,
	}
	if err := validateExactPaneTarget(server.state, protocol.Inbound{PaneID: "pane-1", Target: &exact}, true); err != nil {
		t.Fatalf("exact target rejected: %#v", err)
	}
	for name, mutate := range map[string]func(*protocol.TargetRef){
		"server session": func(target *protocol.TargetRef) { target.ServerSessionID = "other" },
		"pane":           func(target *protocol.TargetRef) { target.PaneID = "pane-2" },
		"terminal":       func(target *protocol.TargetRef) { target.TerminalID = "terminal-2" },
		"generation":     func(target *protocol.TargetRef) { target.Generation++ },
		"agent session":  func(target *protocol.TargetRef) { target.AgentSessionID = "agent-session-2" },
	} {
		t.Run(name, func(t *testing.T) {
			changed := exact
			mutate(&changed)
			if err := validateExactPaneTarget(server.state, protocol.Inbound{PaneID: "pane-1", Target: &changed}, true); err == nil {
				t.Fatal("stale target was accepted")
			}
		})
	}
	if err := validateExactPaneTarget(server.state, protocol.Inbound{PaneID: "pane-1"}, true); err == nil {
		t.Fatal("authenticated pane command without a target was accepted")
	}
	if err := validateExactPaneTarget(server.state, protocol.Inbound{PaneID: "pane-1"}, false); err != nil {
		t.Fatalf("local pane command without a target was rejected: %#v", err)
	}
}

func TestValidateExactPaneTargetAllowsStaleOwnerCleanup(t *testing.T) {
	server := testServer()
	server.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", ServerSessionID: "primary", TerminalID: "terminal-new",
		Generation: 5, SessionID: "agent-session-new",
	}}, server.state.RevisionCounter())
	stale := protocol.TargetRef{
		ServerSessionID: "primary", PaneID: "pane-1", TerminalID: "terminal-old",
		Generation: 4, AgentSessionID: "agent-session-old",
	}
	for _, action := range []string{"unwatch_pane", "release_pane_size", "cancel_speech"} {
		if err := validateExactPaneTarget(server.state, protocol.Inbound{
			Type: action, PaneID: "pane-1", Target: &stale,
		}, true); err != nil {
			t.Fatalf("%s rejected stale cleanup target: %#v", action, err)
		}
	}
	stale.PaneID = "pane-2"
	if err := validateExactPaneTarget(server.state, protocol.Inbound{
		Type: "unwatch_pane", PaneID: "pane-1", Target: &stale,
	}, true); err == nil {
		t.Fatal("cleanup accepted a different pane")
	}
}

// The agents broadcast deep-copies snapshots through JSON before projecting
// wire identity, and the phone can only echo what that copy advertises. The
// identity that survives the round trip must satisfy validateExactPaneTarget,
// or every command against an agent with a resolved session is rejected -
// exactly the shape of the field failure this test was written after: the
// internal SessionID is json:"-", so it silently vanished from the broadcast
// and phones echoed an empty agent_session_id forever.
func TestBroadcastAgentIdentitySatisfiesExactTargetValidation(t *testing.T) {
	server := testServer()
	agent := &coordinator.AgentState{
		PaneID: "pane-1", RawPaneID: "pane-1", TerminalID: "terminal-1",
		Agent: "omp", Status: "working",
		Session: "/home/user/.omp/agent/sessions/-work/2026-08-30T19-57-25-194Z_x.jsonl",
	}
	server.resolveAgentSessionName(agent)
	server.state.CommitInventory([]*coordinator.AgentState{agent}, server.state.RevisionCounter())

	data, err := json.Marshal(server.state.Snapshot())
	if err != nil {
		t.Fatal(err)
	}
	var wire []*coordinator.AgentState
	if err := json.Unmarshal(data, &wire); err != nil {
		t.Fatal(err)
	}
	server.projectAgentResources(wire)
	advertised := wire[0]
	if advertised.AgentSessionID == "" {
		t.Fatal("agents broadcast lost the agent session identity")
	}
	echoed := protocol.TargetRef{
		ServerSessionID: advertised.ServerSessionID,
		PaneID:          advertised.RawPaneID,
		TerminalID:      advertised.TerminalID,
		Generation:      advertised.Generation,
		AgentSessionID:  advertised.AgentSessionID,
	}
	if err := validateExactPaneTarget(server.state, protocol.Inbound{PaneID: "pane-1", Target: &echoed}, true); err != nil {
		t.Fatalf("broadcast identity rejected by exact-target validation: %#v", err)
	}
}

func TestBoundPushPolicyUsesAuthenticatedDevice(t *testing.T) {
	current := push.DefaultDevicePolicy("old-device", "en")
	raw := json.RawMessage(`{
		"device_id":"spoofed-device",
		"locale":"spoofed-locale",
		"categories":{"attention":true,"question":false,"brief":true,"finished":false,"update":true,"test":true},
		"settle_ms":5000,
		"cooldown_ms":60000,
		"snoozed":true,
		"snooze_until":"2026-08-31T13:00:00Z",
		"update_once":false
	}`)
	policy, err := boundPushPolicy(raw, "authenticated-device", "zh-CN", current)
	if err != nil {
		t.Fatal(err)
	}
	if policy.DeviceID != "authenticated-device" || policy.Locale != "zh-CN" ||
		policy.Settle != 5*time.Second || policy.Cooldown != time.Minute ||
		!policy.Snoozed || policy.UpdateOnce {
		t.Fatalf("bound policy = %#v", policy)
	}
}

func TestResolveAgentSessionName(t *testing.T) {
	home := t.TempDir()
	codexDir := filepath.Join(home, ".codex")
	const codexSessionID = "123e4567-e89b-12d3-a456-426614174001"
	rolloutPath := filepath.Join(codexDir, "sessions", "2026", "08", "12", "rollout-2026-08-12T10-00-00-"+codexSessionID+".jsonl")
	if err := os.MkdirAll(filepath.Dir(rolloutPath), 0o755); err != nil {
		t.Fatal(err)
	}
	row, err := json.Marshal(map[string]any{
		"timestamp": "2026-08-12T10:00:00Z", "type": "response_item",
		"payload": map[string]any{"type": "message", "role": "user",
			"content": []any{map[string]any{"type": "input_text", "text": "build it"}}},
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(rolloutPath, append(row, '\n'), 0o644); err != nil {
		t.Fatal(err)
	}
	index := []byte("{\"id\":\"" + codexSessionID + "\",\"thread_name\":\"current-session\"}\n")
	if err := os.WriteFile(filepath.Join(codexDir, "session_index.jsonl"), index, 0o644); err != nil {
		t.Fatal(err)
	}

	s := testServer()
	s.sessions = session.NewResolver(home)

	// named carries a canonical session id with both an index record and the
	// rollout the reader would serve, the shape Locate requires post round-3.
	named := &coordinator.AgentState{Agent: "codex", Session: codexSessionID}
	s.resolveAgentSessionName(named)
	if named.SessionName != "current-session" || named.Session != "current-session" ||
		named.SessionID != codexSessionID || !named.ConversationHistoryAvailable {
		t.Fatalf("named session = %#v, want resolved display name and retained history identity", named)
	}

	unnamed := &coordinator.AgentState{Agent: "codex", Session: "missing-session"}
	s.resolveAgentSessionName(unnamed)
	if unnamed.SessionName != "" || unnamed.Session != "missing-session" ||
		unnamed.SessionID != "missing-session" || !unnamed.ConversationHistoryAvailable {
		t.Fatalf("unnamed session = %#v, want preserved history identity", unnamed)
	}
}

// A whitespace-only session value is what herdr reports for a pane with no
// real session yet - not the same as an empty string, but every other
// consumer (Reader.Read, latestConversationResponse, the activity backfill
// path) treats it as one via TrimSpace. Before the fix,
// resolveAgentSessionName did not, so the untrimmed value survived the
// `== ""` guard and reached the resolver's empty-id sole-transcript
// heuristic, which - given a cwd whose project directory holds exactly one
// transcript - invents a title for a session that was never reported. The
// conversation view for the same (agent, cwd) reads its session id through
// Reader.Read, which trims it back to empty and answers "not available", so
// the pane would show a confident title next to an unavailable transcript.
func TestResolveAgentSessionNameTrimsWhitespaceOnlySession(t *testing.T) {
	home := t.TempDir()
	const cwd = "/work/app"
	writeClaudeTranscript(t, filepath.Join(home, ".claude", "projects", "-work-app", invariantSession+".jsonl"), "Sole Transcript Title")

	s := testServer()
	s.sessions = session.NewResolver(home)

	agent := &coordinator.AgentState{Agent: "claude", Cwd: cwd, Session: "   "}
	s.resolveAgentSessionName(agent)
	if agent.SessionName != "" {
		t.Fatalf("SessionName = %q, want empty for a whitespace-only session", agent.SessionName)
	}
	if agent.SessionID != "" {
		t.Fatalf("SessionID = %q, want empty for a whitespace-only session", agent.SessionID)
	}
	if agent.ConversationHistoryAvailable {
		t.Fatal("ConversationHistoryAvailable = true, want false for a whitespace-only session")
	}
}

func TestCaptureFinishedPanePrefersConversationResponse(t *testing.T) {
	home := t.TempDir()
	sessionID := "01a00af4-9706-7000-81b5-390a66466563"
	path := filepath.Join(home, ".omp", "agent", "sessions", "-relay", "session_"+sessionID+".jsonl")
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		t.Fatal(err)
	}
	file, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	encoder := json.NewEncoder(file)
	rows := []map[string]any{
		{
			"type": "message",
			"message": map[string]any{
				"role":    "user",
				"content": []any{map[string]any{"type": "text", "text": "Review the change"}},
			},
		},
		{
			"type":      "message",
			"timestamp": "2026-08-16T14:24:45.112Z",
			"message": map[string]any{
				"role": "assistant",
				"content": []any{map[string]any{"type": "text", "text": strings.Join([]string{
					"Here is the complete response.",
					"",
					"1. The first detail.",
					"2. The second detail.",
					"3. The third detail.",
					"4. The fourth detail.",
					"5. The fifth detail.",
					"6. The sixth detail.",
					"7. The seventh detail.",
					"8. The eighth detail.",
					"9. The ninth detail.",
					"10. The tenth detail.",
					"11. The eleventh detail.",
					"12. The twelfth detail.",
				}, "\n")}},
			},
		},
	}
	for _, row := range rows {
		if err := encoder.Encode(row); err != nil {
			_ = file.Close()
			t.Fatal(err)
		}
	}
	if err := file.Close(); err != nil {
		t.Fatal(err)
	}

	s := testServer()
	s.conversationM = conversation.NewReader(home)
	want := rows[1]["message"].(map[string]any)["content"].([]any)[0].(map[string]any)["text"].(string)
	if got := s.captureFinishedPane(context.Background(), "pane-1", "omp", "", sessionID); got != want {
		t.Fatalf("captured response = %q, want full conversation response %q", got, want)
	}

	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "omp", Status: "idle", SessionID: path,
	}}, s.state.RevisionCounter())
	s.activityView = []activity.Entry{{
		ID: "old-finished", Timestamp: activity.MilliTimestamp(time.Date(2026, time.August, 16, 14, 24, 46, 0, time.UTC).UnixMilli()),
		Kind: "finished", Status: "completed", Agent: "omp", PaneID: "pane-1", Session: "Old title",
	}}
	backfilled := s.recentActivities(1)
	if len(backfilled) != 1 || backfilled[0].Extract != want {
		t.Fatalf("backfilled activity = %#v, want full conversation response", backfilled)
	}
}

func TestCaptureFinishedPaneUsesOriginalConversationCwd(t *testing.T) {
	home := t.TempDir()
	const sessionID = "123e4567-e89b-12d3-a456-426614174321"
	oldCWD := "/work/old-pane"
	oldForeground := "/work/old-foreground"
	newCWD := "/work/new-pane"
	newForeground := "/work/new-foreground"
	writeClaudeTranscriptAnswering(t,
		filepath.Join(home, ".claude", "projects", "-work-old-foreground", sessionID+".jsonl"),
		"Old work", "answer from original cwd")
	writeClaudeTranscriptAnswering(t,
		filepath.Join(home, ".claude", "projects", "-work-new-foreground", sessionID+".jsonl"),
		"New work", "answer from current cwd")

	s := testServer()
	s.conversationM = conversation.NewReader(home)
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Cwd: newCWD, ForegroundCwd: newForeground, SessionID: sessionID,
	}}, s.state.RevisionCounter())

	if got := s.captureFinishedPane(context.Background(), "pane-1", "claude", oldCWD, sessionID,
		conversation.ProjectContext{CWD: oldCWD, ForegroundCWD: oldForeground}); got != "answer from original cwd" {
		t.Fatalf("captured response = %q, want the transcript bound to the completion's original project", got)
	}
}

func TestActivityBackfillKeepsHistoricalSessionCwdEmpty(t *testing.T) {
	home := t.TempDir()
	const sessionID = "123e4567-e89b-12d3-a456-426614174399"
	writeClaudeTranscriptAnswering(t,
		filepath.Join(home, ".claude", "projects", "-work-old", sessionID+".jsonl"),
		"Old work", "historical answer")

	s := testServer()
	s.conversationM = conversation.NewReader(home)
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Cwd: "/work/new", ForegroundCwd: "/work/unrelated",
	}}, s.state.RevisionCounter())
	s.activityView = []activity.Entry{{
		ID:        "historical-finished",
		Timestamp: activity.MilliTimestamp(time.Date(2026, time.August, 12, 10, 0, 2, 0, time.UTC).UnixMilli()),
		Kind:      "finished",
		Status:    "completed",
		Agent:     "claude",
		PaneID:    "pane-1",
		Session:   sessionID,
	}}

	backfilled := s.recentActivities(1)
	if len(backfilled) != 1 || backfilled[0].Extract != "historical answer" {
		t.Fatalf("historical activity = %#v, want response located without current pane cwd", backfilled)
	}
}

func TestActivityBackfillUsesLiveForegroundProject(t *testing.T) {
	home := t.TempDir()
	const sessionID = "123e4567-e89b-12d3-a456-426614174398"
	writeClaudeTranscriptAnswering(t,
		filepath.Join(home, ".claude", "projects", "-work-pane", sessionID+".jsonl"),
		"Pane copy", "pane answer")
	writeClaudeTranscriptAnswering(t,
		filepath.Join(home, ".claude", "projects", "-work-foreground", sessionID+".jsonl"),
		"Foreground copy", "foreground answer")

	s := testServer()
	s.conversationM = conversation.NewReader(home)
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Cwd: "/work/pane", ForegroundCwd: "/work/foreground", SessionID: sessionID,
	}}, s.state.RevisionCounter())
	s.activityView = []activity.Entry{{
		ID: "live-finished", Kind: "finished", Status: "completed", Agent: "claude", PaneID: "pane-1", Session: sessionID,
	}}

	backfilled := s.recentActivities(1)
	if len(backfilled) != 1 || backfilled[0].Extract != "foreground answer" {
		t.Fatalf("live foreground activity = %#v, want foreground response", backfilled)
	}
}

func TestLocatedAgentDirUsesTranscriptInsteadOfRawSessionID(t *testing.T) {
	home := t.TempDir()
	profile := t.TempDir()
	t.Setenv(agentroots.OMPListEnv, profile)
	const sessionID = "123e4567-e89b-12d3-a456-426614174321"
	path := filepath.Join(profile, "sessions", "-work", "session_"+sessionID+".jsonl")
	writeInvariantRows(t, path,
		map[string]any{"type": "message", "message": map[string]any{"role": "user", "content": "question"}})

	reader := conversation.NewReader(home)
	location := reader.Locate("omp", "/work", sessionID)
	if location.Path != path {
		t.Fatalf("location = %#v, want profile transcript %q", location, path)
	}
	if got := locatedAgentDir(home, "omp", location); got != profile {
		t.Fatalf("agent dir = %q, want active profile %q", got, profile)
	}
	if raw := agentroots.AgentDirForSession(home, "omp", sessionID); raw != "" {
		t.Fatalf("raw session ID unexpectedly selected an agent directory: %q", raw)
	}
}

func TestForegroundClaudeTranscriptUsesConfiguredRoot(t *testing.T) {
	home := t.TempDir()
	profile := t.TempDir()
	t.Setenv(agentroots.ClaudeListEnv, profile)
	const sessionID = "123e4567-e89b-12d3-a456-426614174322"
	path := filepath.Join(profile, "projects", "-work-foreground", sessionID+".jsonl")
	writeInvariantRows(t, path,
		map[string]any{"type": "assistant", "message": map[string]any{"content": "question"}})

	reader := conversation.NewReader(home)
	location := reader.LocateWithProject("claude", conversation.ProjectContext{
		CWD: "/work/pane", ForegroundCWD: "/work/foreground",
	}, sessionID)
	if location.Path != path || location.Root != filepath.Join(profile, "projects") {
		t.Fatalf("location = %#v, want foreground profile transcript %q in configured root", location, path)
	}
}

func TestConversationHistoryCommandFollowsClaudeContinuation(t *testing.T) {
	home := t.TempDir()
	anchor := "123e4567-e89b-12d3-a456-426614174000"
	child := "123e4567-e89b-12d3-a456-426614174001"
	root := filepath.Join(home, ".claude", "projects", "-work-foreground")
	writeInvariantRows(t, filepath.Join(root, anchor+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "a1", "message": map[string]any{"content": "parent response"}},
		map[string]any{"type": "continued-in", "sessionId": anchor, "continuedInSessionId": child},
	)
	writeInvariantRows(t, filepath.Join(root, child+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "b1", "message": map[string]any{"content": "new child response"}},
	)
	server := testServer()
	if server.conversationB != nil {
		_ = server.conversationB.Close()
	}
	reader := conversation.NewReader(home)
	browser, err := conversation.NewBrowser(reader, t.TempDir(), conversation.DefaultBrowserOptions())
	if err != nil {
		t.Fatal(err)
	}
	server.conversationM = reader
	server.conversationB = browser
	server.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Cwd: "/work/pane", ForegroundCwd: "/work/foreground", SessionID: anchor,
		TerminalID: "terminal-1", ServerSessionID: "primary", Status: "working",
	}}, server.state.RevisionCounter())
	server.hub.SetHandler(func(client *transport.ClientConn, message map[string]any, admitted func()) {
		defer admitted()
		inbound, decodeErr := protocol.DecodeMap(message)
		if decodeErr != nil {
			t.Errorf("decode history command: %v", decodeErr)
			return
		}
		server.handleConversationHistory(client, inbound)
	})
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	defer func() {
		server.hub.Shutdown(context.Background())
		browser.Close()
	}()
	conn, _, err := websocket.Dial(context.Background(), "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.CloseNow()
	payload, err := json.Marshal(map[string]any{
		"type": "get_conversation_history", "request_id": "history-1", "pane_id": "pane-1", "limit": 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := conn.Write(ctx, websocket.MessageText, payload); err != nil {
		t.Fatal(err)
	}
	_, data, err := conn.Read(ctx)
	if err != nil {
		t.Fatal(err)
	}
	var response struct {
		OK   bool `json:"ok"`
		Data struct {
			Entries []struct {
				Text string `json:"text"`
			} `json:"entries"`
			NextCursor string `json:"next_cursor"`
		} `json:"data"`
	}
	if err := json.Unmarshal(data, &response); err != nil {
		t.Fatal(err)
	}
	if !response.OK || len(response.Data.Entries) != 1 || response.Data.Entries[0].Text != "new child response" || response.Data.NextCursor == "" {
		t.Fatalf("history command response = %s", data)
	}

	olderPayload, err := json.Marshal(map[string]any{
		"type": "get_conversation_history", "request_id": "history-2", "pane_id": "pane-1",
		"cursor": response.Data.NextCursor, "limit": 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := conn.Write(ctx, websocket.MessageText, olderPayload); err != nil {
		t.Fatal(err)
	}
	if _, data, err = conn.Read(ctx); err != nil {
		t.Fatal(err)
	}
	var older struct {
		OK   bool `json:"ok"`
		Data struct {
			Entries []struct {
				Text string `json:"text"`
			} `json:"entries"`
		} `json:"data"`
	}
	if err := json.Unmarshal(data, &older); err != nil {
		t.Fatal(err)
	}
	if !older.OK || len(older.Data.Entries) != 1 || older.Data.Entries[0].Text != "parent response" {
		t.Fatalf("older history command response = %s", data)
	}
}

func TestConversationHistoryRejectsForegroundChangeDuringRead(t *testing.T) {
	home := t.TempDir()
	const sessionID = "123e4567-e89b-12d3-a456-426614174323"
	oldCWD := "/work/pane"
	oldForeground := "/work/foreground"
	newForeground := "/work/other-foreground"
	writeInvariantRows(t, filepath.Join(home, ".claude", "projects", "-work-foreground", sessionID+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "answer", "message": map[string]any{"content": "foreground answer"}})

	server := testServer()
	if server.conversationB != nil {
		_ = server.conversationB.Close()
	}
	reader := conversation.NewReader(home)
	browser, err := conversation.NewBrowser(reader, t.TempDir(), conversation.DefaultBrowserOptions())
	if err != nil {
		t.Fatal(err)
	}
	server.conversationM = reader
	server.conversationB = browser
	server.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Cwd: oldCWD, ForegroundCwd: oldForeground, SessionID: sessionID,
		TerminalID: "terminal-1", ServerSessionID: "primary", Status: "working",
	}}, server.state.RevisionCounter())

	readEntered := make(chan struct{})
	releaseRead := make(chan struct{})
	server.conversationHistoryReadObserver = func() {
		close(readEntered)
		<-releaseRead
	}
	server.hub.SetHandler(func(client *transport.ClientConn, message map[string]any, admitted func()) {
		defer admitted()
		inbound, decodeErr := protocol.DecodeMap(message)
		if decodeErr != nil {
			t.Errorf("decode history command: %v", decodeErr)
			return
		}
		server.handleConversationHistory(client, inbound)
	})
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	defer func() {
		server.hub.Shutdown(context.Background())
		browser.Close()
	}()
	conn, _, err := websocket.Dial(context.Background(), "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.CloseNow()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	payload, err := json.Marshal(map[string]any{
		"type": "get_conversation_history", "request_id": "history-stale", "pane_id": "pane-1", "limit": 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := conn.Write(ctx, websocket.MessageText, payload); err != nil {
		t.Fatal(err)
	}
	select {
	case <-readEntered:
	case <-ctx.Done():
		t.Fatal("history read did not reach the deterministic barrier")
	}

	server.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Cwd: oldCWD, ForegroundCwd: newForeground, SessionID: sessionID,
		TerminalID: "terminal-1", ServerSessionID: "primary", Status: "working",
	}}, server.state.RevisionCounter())
	close(releaseRead)
	_, data, err := conn.Read(ctx)
	if err != nil {
		t.Fatal(err)
	}
	var response struct {
		OK    bool   `json:"ok"`
		Error string `json:"error"`
	}
	if err := json.Unmarshal(data, &response); err != nil {
		t.Fatal(err)
	}
	if response.OK || response.Error != "Agent changed while conversation history was loading" {
		t.Fatalf("stale history response = %s", data)
	}
}

func TestLatestConversationResponseFollowsClaudeContinuation(t *testing.T) {
	home := t.TempDir()
	anchor := "123e4567-e89b-12d3-a456-426614174000"
	child := "123e4567-e89b-12d3-a456-426614174001"
	root := filepath.Join(home, ".claude", "projects", "-work")
	writeInvariantRows(t, filepath.Join(root, anchor+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "a1", "message": map[string]any{"content": "parent response"}},
		map[string]any{"type": "continued-in", "sessionId": anchor, "continuedInSessionId": child},
	)
	writeInvariantRows(t, filepath.Join(root, child+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "b1", "message": map[string]any{"content": "new child response"}},
	)
	server := testServer()
	server.conversationM = conversation.NewReader(home)
	if got := server.latestConversationResponse("claude", "/work", anchor); got != "new child response" {
		t.Fatalf("latest conversation response = %q, want child response", got)
	}
}

func TestCaptureFinishedPaneFollowsClaudeContinuation(t *testing.T) {
	home := t.TempDir()
	anchor := "123e4567-e89b-12d3-a456-426614174000"
	child := "123e4567-e89b-12d3-a456-426614174001"
	root := filepath.Join(home, ".claude", "projects", "-work")
	writeInvariantRows(t, filepath.Join(root, anchor+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "a1", "message": map[string]any{"content": "stale parent response"}},
		map[string]any{"type": "continued-in", "sessionId": anchor, "continuedInSessionId": child},
	)
	writeInvariantRows(t, filepath.Join(root, child+".jsonl"),
		map[string]any{"type": "assistant", "uuid": "b1", "message": map[string]any{"content": "finished child response"}},
	)
	server := testServer()
	server.conversationM = conversation.NewReader(home)
	if got := server.captureFinishedPane(context.Background(), "pane-1", "claude", "/work", anchor); got != "finished child response" {
		t.Fatalf("finished-pane extraction = %q, want child response", got)
	}
}

func TestForegroundCwdIsNotSerializedInAgentPayload(t *testing.T) {
	agent := &coordinator.AgentState{Agent: "claude", Cwd: "/work/pane", ForegroundCwd: "/work/foreground"}
	data, err := json.Marshal(agent)
	if err != nil {
		t.Fatal(err)
	}
	var payload map[string]any
	if err := json.Unmarshal(data, &payload); err != nil {
		t.Fatal(err)
	}
	if payload["cwd"] != agent.Cwd || strings.Contains(string(data), "foreground_cwd") || strings.Contains(string(data), agent.ForegroundCwd) {
		t.Fatalf("serialized agent payload = %s, want pane cwd only", data)
	}
}

func TestConversationTupleIncludesAgentCwdAndSession(t *testing.T) {
	base := &coordinator.AgentState{Agent: "claude", Cwd: "/work", SessionID: "session"}
	if !sameConversationTuple(base, &coordinator.AgentState{Agent: "claude", Cwd: "/work", SessionID: "session"}) {
		t.Fatal("identical conversation tuples did not match")
	}
	for name, changed := range map[string]*coordinator.AgentState{
		"agent":      {Agent: "qoder", Cwd: "/work", SessionID: "session"},
		"cwd":        {Agent: "claude", Cwd: "/other", SessionID: "session"},
		"foreground": {Agent: "claude", Cwd: "/work", ForegroundCwd: "/work/tree", SessionID: "session"},
		"session":    {Agent: "claude", Cwd: "/work", SessionID: "other"},
	} {
		if sameConversationTuple(base, changed) {
			t.Errorf("%s change was not detected", name)
		}
	}
}

func TestPublishCurrentInventoryRepairsReadyRecovery(t *testing.T) {
	server := testServer()
	t.Cleanup(func() {
		if server.conversationB != nil {
			_ = server.conversationB.Close()
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = server.hub.Shutdown(ctx)
	})
	server.state.CommitWorkspaces([]herdr.Workspace{{ID: "workspace-1", Label: "Project"}})
	server.setInventoryPublisher(context.Background())
	server.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "codex", Status: "working", Project: "Project",
	}}, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	server.state.MarkInventoryFailure(errors.New("topology churn"))
	publishInventoryForTest(t, server)
	if got := server.committedInventoryStatus()["state"]; got != "error" {
		t.Fatalf("degraded committed status = %v, want error", got)
	}
	server.state.CommitInventory(server.state.Snapshot(), server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	committed := server.committedInventorySnapshot()
	if committed.status["state"] != "ready" || len(committed.agents) != 1 || len(committed.workspaces) != 1 {
		t.Fatalf("recovery committed snapshot = %#v, want ready topology", committed)
	}
}

func TestPublishCurrentInventoryCommitsEmptyReadyRecoveryWithoutClients(t *testing.T) {
	server := testServer()
	t.Cleanup(func() {
		if server.conversationB != nil {
			_ = server.conversationB.Close()
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = server.hub.Shutdown(ctx)
	})
	server.setInventoryPublisher(context.Background())
	server.state.CommitInventory(nil, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	server.state.MarkInventoryFailure(errors.New("command failed"))
	publishInventoryForTest(t, server)
	server.state.CommitInventory(nil, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	committed := server.committedInventorySnapshot()
	if committed.status["state"] != "ready" || committed.agents == nil || committed.workspaces == nil {
		t.Fatalf("empty recovery committed snapshot = %#v", committed)
	}
	if len(committed.agents) != 0 || len(committed.workspaces) != 0 {
		t.Fatalf("empty recovery retained topology: %#v", committed)
	}
}

func TestPublishCurrentInventoryOrdersRecoveryForConnectedRefreshAndReconnect(t *testing.T) {
	server := testServer()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	defer server.hub.Shutdown(ctx)
	server.setInventoryPublisher(ctx)
	server.state.CommitWorkspaces([]herdr.Workspace{{ID: "workspace-1", Label: "Project"}})
	server.state.CommitInventory([]*coordinator.AgentState{{PaneID: "pane-1", Agent: "codex", Status: "idle"}}, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	connected := make(chan *transport.ClientConn, 2)
	server.hub.SetOnConnect(func(client *transport.ClientConn) { connected <- client })
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	dial := func() *websocket.Conn {
		conn, _, err := websocket.Dial(ctx, "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
		if err != nil {
			t.Fatal(err)
		}
		return conn
	}
	readType := func(conn *websocket.Conn) string {
		_, data, err := conn.Read(ctx)
		if err != nil {
			t.Fatal(err)
		}
		var message map[string]any
		if err := json.Unmarshal(data, &message); err != nil {
			t.Fatal(err)
		}
		typeName, _ := message["type"].(string)
		return typeName
	}
	conn := dial()
	client := <-connected
	server.state.MarkInventoryFailure(errors.New("topology churn"))
	publishInventoryForTest(t, server)
	if got := readType(conn); got != "inventory_status" {
		t.Fatalf("degraded connected frame = %q, want inventory_status", got)
	}
	server.state.CommitInventory([]*coordinator.AgentState{{PaneID: "pane-1", Agent: "codex", Status: "idle"}}, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	for index, want := range []string{"inventory_status", "agents", "workspaces"} {
		if got := readType(conn); got != want {
			t.Fatalf("recovery frame %d = %q, want %q", index, got, want)
		}
	}
	server.requestAgentRefresh(client)
	for index, want := range []string{"inventory_status", "agents", "workspaces"} {
		if got := readType(conn); got != want {
			t.Fatalf("immediate refresh frame %d = %q, want %q", index, got, want)
		}
	}
	// The production refresh handler queues a deferred completion. An unchanged
	// successful publication must drain it even though no agent diff occurred.
	publishInventoryForTest(t, server)
	for index, want := range []string{"inventory_status", "agents", "workspaces"} {
		if got := readType(conn); got != want {
			t.Fatalf("unchanged deferred refresh frame %d = %q, want %q", index, got, want)
		}
	}
	conn.CloseNow()

	server.hub.SetOnConnect(func(client *transport.ClientConn) {
		server.sendConnectionSnapshot(client)
		connected <- client
	})
	reconnected := dial()
	<-connected
	for index, want := range []string{"push_config", "agents", "workspaces", "activity_history", "inventory_status"} {
		if got := readType(reconnected); got != want {
			t.Fatalf("reconnect frame %d = %q, want %q", index, got, want)
		}
	}
	reconnected.CloseNow()
}

func TestProductionInventoryPublisherOrdersRefreshAndRegistrationBarriers(t *testing.T) {
	server := testServer()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	defer func() {
		if server.conversationB != nil {
			_ = server.conversationB.Close()
		}
		_ = server.hub.Shutdown(ctx)
	}()
	server.setInventoryPublisher(ctx)
	workspace := herdr.Workspace{ID: "workspace-1", Label: "Project"}
	agent := &coordinator.AgentState{PaneID: "pane-1", Agent: "codex", Status: "idle", Project: "Project"}
	server.state.CommitWorkspaces([]herdr.Workspace{workspace})
	server.state.CommitInventory([]*coordinator.AgentState{agent}, server.state.RevisionCounter())
	if err := server.publishCurrentInventory(ctx); err != nil {
		t.Fatal(err)
	}

	connected := make(chan *transport.ClientConn, 2)
	server.hub.SetOnConnect(func(client *transport.ClientConn) {
		server.sendConnectionSnapshot(client)
		connected <- client
	})
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	dial := func() *websocket.Conn {
		conn, _, err := websocket.Dial(ctx, "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
		if err != nil {
			t.Fatal(err)
		}
		return conn
	}
	readMessage := func(conn *websocket.Conn) map[string]any {
		t.Helper()
		_, data, err := conn.Read(ctx)
		if err != nil {
			t.Fatal(err)
		}
		var message map[string]any
		if err := json.Unmarshal(data, &message); err != nil {
			t.Fatal(err)
		}
		return message
	}
	readHandshake := func(conn *websocket.Conn) string {
		t.Helper()
		push := readMessage(conn)
		if push["type"] != "push_config" {
			t.Fatalf("handshake push_config = %#v", push)
		}
		inventory, ok := push["inventory"].(map[string]any)
		if !ok {
			t.Fatalf("handshake inventory = %#v", push)
		}
		state, _ := inventory["state"].(string)
		if state != "ready" && state != "error" {
			t.Fatalf("handshake inventory state = %#v", inventory)
		}
		if agents := readMessage(conn); agents["type"] != "agents" {
			t.Fatalf("handshake agents = %#v", agents)
		}
		if workspaces := readMessage(conn); workspaces["type"] != "workspaces" {
			t.Fatalf("handshake workspaces = %#v", workspaces)
		}
		if activity := readMessage(conn); activity["type"] != "activity_history" {
			t.Fatalf("handshake activity = %#v", activity)
		}
		status := readMessage(conn)
		if status["type"] != "inventory_status" || status["state"] != state {
			t.Fatalf("handshake status = %#v, want %q", status, state)
		}
		return state
	}
	conn := dial()
	client := <-connected
	if got := readHandshake(conn); got != "ready" {
		t.Fatalf("initial handshake state = %q", got)
	}

	server.state.MarkInventoryFailure(errors.New("topology churn"))
	if err := server.publishCurrentInventory(ctx); err != nil {
		t.Fatal(err)
	}
	degraded := readMessage(conn)
	if degraded["type"] != "inventory_status" || degraded["state"] != "error" {
		t.Fatalf("degraded publication = %#v", degraded)
	}

	// Hold the real Hub registration barrier while the production publisher,
	// immediate refresh, and a new connection all wait behind it. The state is
	// restored before release, so any operation that captured a stale payload
	// outside the barrier would be observable as an error after a ready batch.
	barrierEntered := make(chan struct{})
	releaseBarrier := make(chan struct{})
	batchDone := make(chan error, 1)
	go func() {
		batchDone <- server.hub.BroadcastBatchPrepared(func() ([]any, func(), error) {
			close(barrierEntered)
			<-releaseBarrier
			return nil, func() {}, nil
		})
	}()
	select {
	case <-barrierEntered:
	case <-ctx.Done():
		t.Fatal("inventory barrier did not start")
	}

	server.state.CommitInventory([]*coordinator.AgentState{agent}, server.state.RevisionCounter())
	published := make(chan error, 1)
	go func() { published <- server.publishCurrentInventory(ctx) }()
	refreshDone := make(chan struct{})
	go func() {
		server.requestAgentRefresh(client)
		close(refreshDone)
	}()
	secondDial := make(chan *websocket.Conn, 1)
	go func() {
		conn, _, err := websocket.Dial(ctx, "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
		if err != nil {
			secondDial <- nil
			return
		}
		secondDial <- conn
	}()
	waitForBlocked := func(name string, done func() bool) {
		t.Helper()
		if done() {
			t.Fatalf("%s overtook the registration barrier", name)
		}
		time.Sleep(20 * time.Millisecond)
		if done() {
			t.Fatalf("%s overtook the registration barrier", name)
		}
	}
	waitForBlocked("inventory publication", func() bool {
		select {
		case <-published:
			return true
		default:
			return false
		}
	})
	waitForBlocked("immediate refresh", func() bool {
		select {
		case <-refreshDone:
			return true
		default:
			return false
		}
	})
	select {
	case <-connected:
		t.Fatal("connection registration overtook the registration barrier")
	case <-time.After(20 * time.Millisecond):
	}

	close(releaseBarrier)
	if err := <-batchDone; err != nil {
		t.Fatal(err)
	}
	if err := <-published; err != nil {
		t.Fatal(err)
	}
	<-refreshDone
	second := <-secondDial
	if second == nil {
		t.Fatal("second connection failed")
	}
	<-connected
	secondState := readHandshake(second)
	if secondState != "error" && secondState != "ready" {
		t.Fatalf("barrier reconnect state = %q", secondState)
	}

	readInventoryBatch := func(wantState string) {
		t.Helper()
		status := readMessage(conn)
		if status["type"] != "inventory_status" || status["state"] != wantState {
			t.Fatalf("barrier refresh status = %#v, want %q", status, wantState)
		}
		agents := readMessage(conn)
		if agents["type"] != "agents" {
			t.Fatalf("barrier refresh agents = %#v", agents)
		}
		rows, ok := agents["agents"].([]any)
		if !ok || len(rows) != 1 || rows[0].(map[string]any)["pane_id"] != agent.PaneID {
			t.Fatalf("barrier refresh agent tuple = %#v", agents)
		}
		workspaces := readMessage(conn)
		if workspaces["type"] != "workspaces" {
			t.Fatalf("barrier refresh workspaces = %#v", workspaces)
		}
		workspaceRows, ok := workspaces["workspaces"].([]any)
		if !ok || len(workspaceRows) != 1 || workspaceRows[0].(map[string]any)["workspace_id"] != workspace.ID {
			t.Fatalf("barrier refresh workspace tuple = %#v", workspaces)
		}
	}
	// The request may acquire the barrier first (error, then ready) or the
	// recovery publication may acquire it first (ready, then ready). In either
	// order there must be no error batch after the first ready batch.
	firstStatus := readMessage(conn)
	if firstStatus["type"] != "inventory_status" {
		t.Fatalf("first barrier status = %#v", firstStatus)
	}
	firstState, _ := firstStatus["state"].(string)
	if firstState != "error" && firstState != "ready" {
		t.Fatalf("first barrier state = %#v", firstStatus)
	}
	firstAgents := readMessage(conn)
	firstWorkspaces := readMessage(conn)
	if firstAgents["type"] != "agents" || firstWorkspaces["type"] != "workspaces" {
		t.Fatalf("first barrier tuple = %#v %#v", firstAgents, firstWorkspaces)
	}
	readInventoryBatch("ready")
	if got := server.committedInventoryStatus()["state"]; got != "ready" {
		t.Fatalf("barrier committed state = %v", got)
	}
	second.CloseNow()
	conn.CloseNow()
}

func TestCommittedInventoryPublicationRepairsZeroListenerRefreshAndReconnect(t *testing.T) {
	server := testServer()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	defer func() {
		if server.conversationB != nil {
			_ = server.conversationB.Close()
		}
		_ = server.hub.Shutdown(ctx)
	}()
	server.setInventoryPublisher(ctx)
	workspace := herdr.Workspace{ID: "workspace-1", Label: "Project"}
	agent := &coordinator.AgentState{PaneID: "pane-1", Agent: "codex", Status: "idle", Project: "Project"}
	server.state.CommitWorkspaces([]herdr.Workspace{workspace})
	server.state.CommitInventory([]*coordinator.AgentState{agent}, server.state.RevisionCounter())
	// This is the same signal path installed by Server.Run, with no listeners
	// attached. The committed cache must still become authoritative.
	publishInventoryForTest(t, server)
	server.state.MarkInventoryFailure(errors.New("topology churn"))
	publishInventoryForTest(t, server)
	server.state.CommitTopology([]*coordinator.AgentState{agent}, []herdr.Workspace{workspace}, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	committed := server.committedInventorySnapshot()
	if committed.status["state"] != "ready" || len(committed.agents) != 1 || committed.agents[0].PaneID != agent.PaneID || len(committed.workspaces) != 1 || committed.workspaces[0].ID != workspace.ID {
		t.Fatalf("zero-listener production recovery = %#v", committed)
	}

	connected := make(chan *transport.ClientConn, 2)
	server.hub.SetOnConnect(func(client *transport.ClientConn) {
		server.sendConnectionSnapshot(client)
		connected <- client
	})
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	dial := func() *websocket.Conn {
		conn, _, dialErr := websocket.Dial(ctx, "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
		if dialErr != nil {
			t.Fatal(dialErr)
		}
		return conn
	}
	readMessage := func(conn *websocket.Conn) map[string]any {
		_, data, readErr := conn.Read(ctx)
		if readErr != nil {
			t.Fatal(readErr)
		}
		var message map[string]any
		if err := json.Unmarshal(data, &message); err != nil {
			t.Fatal(err)
		}
		return message
	}
	assertReady := func(message map[string]any) {
		t.Helper()
		if message["state"] != "ready" {
			t.Fatalf("not-ready inventory message = %#v", message)
		}
	}
	assertTopology := func(message map[string]any) {
		t.Helper()
		if message["type"] == "agents" {
			agents, ok := message["agents"].([]any)
			if !ok || len(agents) != 1 {
				t.Fatalf("agents payload = %#v", message)
			}
			row, ok := agents[0].(map[string]any)
			if !ok || row["pane_id"] != agent.PaneID {
				t.Fatalf("agents payload lost committed pane = %#v", message)
			}
		}
		if message["type"] == "workspaces" {
			workspaces, ok := message["workspaces"].([]any)
			if !ok || len(workspaces) != 1 {
				t.Fatalf("workspaces payload = %#v", message)
			}
			row, ok := workspaces[0].(map[string]any)
			if !ok || row["workspace_id"] != workspace.ID {
				t.Fatalf("workspaces payload lost committed workspace = %#v", message)
			}
		}
	}
	conn := dial()
	client := <-connected
	pushConfig := readMessage(conn)
	if pushConfig["type"] != "push_config" {
		t.Fatalf("initial handshake first message = %#v", pushConfig)
	}
	initialInventory, _ := pushConfig["inventory"].(map[string]any)
	assertReady(initialInventory)
	initialAgents := readMessage(conn)
	initialWorkspaces := readMessage(conn)
	if initialAgents["type"] != "agents" || initialWorkspaces["type"] != "workspaces" {
		t.Fatalf("initial handshake topology = %#v %#v", initialAgents, initialWorkspaces)
	}
	assertTopology(initialAgents)
	assertTopology(initialWorkspaces)
	_ = readMessage(conn) // activity_history
	assertReady(readMessage(conn))

	server.state.MarkInventoryFailure(errors.New("server_not_running"))
	publishInventoryForTest(t, server)
	degraded := readMessage(conn)
	if degraded["type"] != "inventory_status" || degraded["state"] != "error" {
		t.Fatalf("connected degraded publication = %#v", degraded)
	}
	server.state.CommitTopology([]*coordinator.AgentState{agent}, []herdr.Workspace{workspace}, server.state.RevisionCounter())
	publishInventoryForTest(t, server)
	for index, expectedType := range []string{"inventory_status", "agents", "workspaces"} {
		message := readMessage(conn)
		if message["type"] != expectedType {
			t.Fatalf("event recovery message %d = %#v, want %s", index, message, expectedType)
		}
		if expectedType == "inventory_status" {
			assertReady(message)
		} else {
			assertTopology(message)
		}
	}
	server.requestAgentRefresh(client)
	for index, expectedType := range []string{"inventory_status", "agents", "workspaces"} {
		message := readMessage(conn)
		if message["type"] != expectedType {
			t.Fatalf("immediate refresh message %d = %#v, want %s", index, message, expectedType)
		}
		if expectedType == "inventory_status" {
			assertReady(message)
		} else {
			assertTopology(message)
		}
	}
	// The deferred request is drained by an unchanged production publication;
	// it must not depend on a topology diff.
	publishInventoryForTest(t, server)
	for index, expectedType := range []string{"inventory_status", "agents", "workspaces"} {
		message := readMessage(conn)
		if message["type"] != expectedType {
			t.Fatalf("deferred refresh message %d = %#v, want %s", index, message, expectedType)
		}
		if expectedType == "inventory_status" {
			assertReady(message)
		} else {
			assertTopology(message)
		}
	}
	conn.CloseNow()
	reconnected := dial()
	<-connected
	for index, expectedType := range []string{"push_config", "agents", "workspaces", "activity_history", "inventory_status"} {
		message := readMessage(reconnected)
		if message["type"] != expectedType {
			t.Fatalf("reconnect message %d = %#v, want %s", index, message, expectedType)
		}
		if expectedType == "agents" || expectedType == "workspaces" {
			assertTopology(message)
		} else if expectedType == "push_config" {
			inventory, _ := message["inventory"].(map[string]any)
			assertReady(inventory)
		} else if expectedType == "inventory_status" {
			assertReady(message)
		}
	}
	reconnected.CloseNow()
}

// Cancelling the server drops in-flight socket connections, so the fixture sees
// ordinary teardown errors that say nothing about the behaviour under test.
func fixtureConnectionTornDown(err error) bool {
	return errors.Is(err, io.EOF) || errors.Is(err, net.ErrClosed) ||
		errors.Is(err, syscall.EPIPE) || errors.Is(err, syscall.ECONNRESET)
}

func TestProductionEventInventoryRecoveryDrainsRefreshAcrossReconnect(t *testing.T) {
	socketPath := filepath.Join(testSocketDir(t), "s")
	listener, err := net.Listen("unix", socketPath)
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	workspace := map[string]any{"workspace_id": "workspace-1", "label": "Project"}
	pane := map[string]any{
		"pane_id": "pane-1", "terminal_id": "terminal-1", "workspace_id": "workspace-1",
		"tab_id": "tab-1", "agent": "codex", "agent_status": "idle", "cwd": "/work/project",
	}
	agent := map[string]any{
		"pane_id": "pane-1", "terminal_id": "terminal-1", "workspace_id": "workspace-1",
		"tab_id": "tab-1", "agent": "codex", "agent_status": "idle", "cwd": "/work/project",
		"agent_session": map[string]any{"value": "session-1", "kind": "id"},
	}
	snapshot := map[string]any{
		"workspaces": []any{workspace},
		"panes":      []any{pane},
		"agents":     []any{agent},
	}
	pollReady := make(chan struct{})
	pollFailed := make(chan struct{})
	var inventoryCalls atomic.Int32
	var failNextInventory atomic.Bool
	serverDone := make(chan error, 1)
	go func() {
		var serveErr error
		defer func() { serverDone <- serveErr }()
		for {
			conn, acceptErr := listener.Accept()
			if acceptErr != nil {
				if errors.Is(acceptErr, net.ErrClosed) {
					return
				}
				serveErr = acceptErr
				return
			}
			func() {
				defer conn.Close()
				var request struct {
					ID     string `json:"id"`
					Method string `json:"method"`
				}
				if decodeErr := json.NewDecoder(bufio.NewReader(conn)).Decode(&request); decodeErr != nil {
					serveErr = decodeErr
					return
				}
				encoder := json.NewEncoder(conn)
				switch request.Method {
				case "agent.list":
					inventoryCalls.Add(1)
					if failNextInventory.CompareAndSwap(true, false) {
						close(pollFailed)
						serveErr = encoder.Encode(map[string]any{
							"id":    request.ID,
							"error": map[string]any{"code": "server_not_running", "message": "Herdr stopped"},
						})
						return
					}
					serveErr = encoder.Encode(map[string]any{
						"id": request.ID,
						"result": map[string]any{
							"type": "agent_list", "agents": []any{pane},
						},
					})
				case "workspace.list":
					serveErr = encoder.Encode(map[string]any{
						"id": request.ID,
						"result": map[string]any{
							"type": "workspace_list", "workspaces": []any{workspace},
						},
					})
					if inventoryCalls.Load() == 1 {
						close(pollReady)
					}
				case "tab.list", "pane.list":
					serveErr = encoder.Encode(map[string]any{
						"id":    request.ID,
						"error": map[string]any{"code": "unsupported", "message": "fixture omits topology detail"},
					})
				case "events.subscribe":
					serveErr = encoder.Encode(map[string]any{
						"id":     request.ID,
						"result": map[string]any{"type": "subscription_started"},
					})
				case "session.snapshot":
					serveErr = encoder.Encode(map[string]any{
						"id":     request.ID,
						"result": map[string]any{"type": "session_snapshot", "snapshot": snapshot},
					})
				default:
					serveErr = fmt.Errorf("unexpected Herdr event method %q", request.Method)
				}
			}()
			if serveErr != nil {
				return
			}
		}
	}()

	cfg := &config.Config{
		Host: "127.0.0.1", Port: 8375, SocketPath: socketPath,
		PollInterval: 15, CacheDir: t.TempDir(), ConfigHome: t.TempDir(), RuntimeDir: t.TempDir(),
	}
	server := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	defer func() {
		if server.conversationB != nil {
			_ = server.conversationB.Close()
		}
		_ = server.hub.Shutdown(ctx)
	}()
	server.setInventoryPublisher(ctx)
	pollDone := make(chan struct{})
	go func() {
		server.poller.Run(ctx)
		close(pollDone)
	}()
	select {
	case <-pollReady:
	case <-ctx.Done():
		t.Fatal("production poll did not commit its initial inventory")
	}
	// The fake closes pollReady while workspace.list is still returning. Wait
	// for the installed publisher to finish the whole first poll before adding
	// the enrichment barrier, otherwise that barrier could pause the initial
	// poll instead of the event recovery operation.
	waitCommittedState := func(want string) {
		t.Helper()
		for {
			if server.committedInventoryStatus()["state"] == want {
				return
			}
			select {
			case <-ctx.Done():
				t.Fatalf("production committed inventory did not reach %q", want)
			default:
				time.Sleep(time.Millisecond)
			}
		}
	}
	waitCommittedState("ready")

	enteredEnrichment := make(chan struct{})
	releaseEnrichment := make(chan struct{})
	var firstEnrichment atomic.Bool
	server.poller.SetEnrich(func(context.Context, []*coordinator.AgentState) {
		if !firstEnrichment.CompareAndSwap(false, true) {
			return
		}
		close(enteredEnrichment)
		<-releaseEnrichment
	})
	var reconnectWaits atomic.Int32
	server.poller.SetEventReconnectWait(func(context.Context) bool {
		return reconnectWaits.Add(1) == 1
	})

	connected := make(chan *transport.ClientConn, 2)
	server.hub.SetOnConnect(func(client *transport.ClientConn) {
		server.sendConnectionSnapshot(client)
		connected <- client
	})
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	dial := func() *websocket.Conn {
		conn, _, dialErr := websocket.Dial(ctx, "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
		if dialErr != nil {
			t.Fatal(dialErr)
		}
		return conn
	}
	readMessage := func(conn *websocket.Conn) map[string]any {
		_, data, readErr := conn.Read(ctx)
		if readErr != nil {
			t.Fatal(readErr)
		}
		var message map[string]any
		if unmarshalErr := json.Unmarshal(data, &message); unmarshalErr != nil {
			t.Fatal(unmarshalErr)
		}
		return message
	}
	assertTuple := func(message map[string]any, wantState string) {
		t.Helper()
		switch message["type"] {
		case "inventory_status":
			if message["state"] != wantState {
				t.Fatalf("inventory status = %#v, want %q", message, wantState)
			}
		case "agents":
			rows, ok := message["agents"].([]any)
			if !ok || len(rows) != 1 {
				t.Fatalf("agents tuple = %#v", message)
			}
			row, ok := rows[0].(map[string]any)
			if !ok || row["pane_id"] != "pane-1" {
				t.Fatalf("agents tuple lost pane = %#v", message)
			}
		case "workspaces":
			rows, ok := message["workspaces"].([]any)
			if !ok || len(rows) != 1 {
				t.Fatalf("workspaces tuple = %#v", message)
			}
			row, ok := rows[0].(map[string]any)
			if !ok || row["workspace_id"] != "workspace-1" {
				t.Fatalf("workspaces tuple lost workspace = %#v", message)
			}
		default:
			t.Fatalf("unexpected inventory tuple message = %#v", message)
		}
	}

	eventDone := make(chan struct{})
	go func() {
		server.poller.RunEvents(ctx, herdr.NewEventClient(socketPath))
		close(eventDone)
	}()
	select {
	case <-enteredEnrichment:
	case <-ctx.Done():
		t.Fatal("production event bootstrap did not reach enrichment")
	}
	// The event operation has started and is paused before its commit. A real
	// poll failure now races that in-flight event recovery through the installed
	// production publisher; the later ready commit must not be lost.
	failNextInventory.Store(true)
	server.poller.Wake()
	select {
	case <-pollFailed:
	case <-ctx.Done():
		t.Fatal("production poll did not publish its failure")
	}
	waitCommittedState("error")
	conn := dial()
	client := <-connected
	for index := 0; index < 5; index++ {
		message := readMessage(conn)
		if index == 0 {
			inventory, ok := message["inventory"].(map[string]any)
			if !ok || inventory["state"] != "error" {
				t.Fatalf("stale handshake inventory = %#v", message)
			}
			continue
		}
		if index == 1 || index == 2 || index == 4 {
			if index == 4 && message["type"] != "inventory_status" {
				t.Fatalf("handshake status message = %#v", message)
			}
			if index == 1 && message["type"] != "agents" || index == 2 && message["type"] != "workspaces" {
				t.Fatalf("handshake topology message = %#v", message)
			}
			if index == 1 || index == 2 || index == 4 {
				assertTuple(message, "error")
			}
		}
	}
	for server.hub.ClientCount() == 0 {
		select {
		case <-ctx.Done():
			t.Fatal("websocket client was not registered")
		default:
			time.Sleep(time.Millisecond)
		}
	}
	server.requestAgentRefresh(client)
	for index, expected := range []string{"inventory_status", "agents", "workspaces"} {
		message := readMessage(conn)
		if message["type"] != expected {
			t.Fatalf("immediate refresh message %d = %#v, want %s", index, message, expected)
		}
		assertTuple(message, "error")
	}
	close(releaseEnrichment)
	for batch := 0; batch < 2; batch++ {
		for index, expected := range []string{"inventory_status", "agents", "workspaces"} {
			message := readMessage(conn)
			if message["type"] != expected {
				t.Fatalf("event publication batch %d message %d = %#v, want %s", batch, index, message, expected)
			}
			assertTuple(message, "ready")
		}
	}

	conn.CloseNow()
	select {
	case <-eventDone:
	case <-ctx.Done():
		t.Fatal("production event loop did not finish its reconnect schedule")
	}
	if got := reconnectWaits.Load(); got != 2 {
		t.Fatalf("event reconnect waits = %d, want 2", got)
	}
	latest := dial()
	<-connected
	for index := 0; index < 5; index++ {
		message := readMessage(latest)
		if index == 0 {
			inventory, ok := message["inventory"].(map[string]any)
			if !ok || inventory["state"] != "ready" {
				t.Fatalf("reconnect handshake inventory = %#v", message)
			}
		} else if index == 1 || index == 2 || index == 4 {
			if index == 1 && message["type"] != "agents" || index == 2 && message["type"] != "workspaces" || index == 4 && message["type"] != "inventory_status" {
				t.Fatalf("reconnect tuple message = %#v", message)
			}
			assertTuple(message, "ready")
		}
	}
	latest.CloseNow()
	if err := listener.Close(); err != nil {
		t.Fatal(err)
	}
	if serveErr := <-serverDone; serveErr != nil && !fixtureConnectionTornDown(serveErr) {
		t.Fatal(serveErr)
	}
	cancel()
	select {
	case <-pollDone:
	case <-time.After(time.Second):
		t.Fatal("production poller did not stop")
	}
}

func TestProductionPollInventoryRecoveryCommitsWithoutListeners(t *testing.T) {
	socketPath := filepath.Join(testSocketDir(t), "herdr.sock")
	listener, err := net.Listen("unix", socketPath)
	if err != nil {
		t.Fatal(err)
	}
	workspace := map[string]any{"workspace_id": "workspace-1", "label": "Project"}
	pane := map[string]any{
		"pane_id": "pane-1", "terminal_id": "terminal-1", "workspace_id": "workspace-1",
		"tab_id": "tab-1", "agent": "codex", "agent_status": "idle", "cwd": "/work/project",
	}
	firstReady := make(chan struct{})
	degraded := make(chan struct{})
	degradedAgain := make(chan struct{})
	recovered := make(chan struct{})
	unchanged := make(chan struct{})
	var inventoryCalls atomic.Int32
	serverDone := make(chan error, 1)
	go func() {
		var serveErr error
		defer func() { serverDone <- serveErr }()
		for {
			conn, acceptErr := listener.Accept()
			if acceptErr != nil {
				if errors.Is(acceptErr, net.ErrClosed) {
					return
				}
				serveErr = acceptErr
				return
			}
			func() {
				defer conn.Close()
				var request struct {
					ID     string `json:"id"`
					Method string `json:"method"`
				}
				if decodeErr := json.NewDecoder(bufio.NewReader(conn)).Decode(&request); decodeErr != nil {
					serveErr = decodeErr
					return
				}
				encoder := json.NewEncoder(conn)
				switch request.Method {
				case "agent.list":
					call := inventoryCalls.Add(1)
					if call == 2 || call == 3 {
						if call == 2 {
							close(degraded)
						} else {
							close(degradedAgain)
						}
						serveErr = encoder.Encode(map[string]any{
							"id":    request.ID,
							"error": map[string]any{"code": "server_not_running", "message": "Herdr stopped"},
						})
						return
					}
					serveErr = encoder.Encode(map[string]any{
						"id":     request.ID,
						"result": map[string]any{"type": "agent_list", "agents": []any{pane}},
					})
				case "workspace.list":
					serveErr = encoder.Encode(map[string]any{
						"id":     request.ID,
						"result": map[string]any{"type": "workspace_list", "workspaces": []any{workspace}},
					})
					switch inventoryCalls.Load() {
					case 1:
						close(firstReady)
					case 4:
						close(recovered)
					case 5:
						close(unchanged)
					}
				case "tab.list", "pane.list":
					serveErr = encoder.Encode(map[string]any{
						"id":    request.ID,
						"error": map[string]any{"code": "unsupported", "message": "fixture omits topology detail"},
					})
				default:
					serveErr = fmt.Errorf("unexpected Herdr poll method %q", request.Method)
				}
			}()
			if serveErr != nil {
				return
			}
		}
	}()

	cfg := &config.Config{
		Host: "127.0.0.1", Port: 8375, SocketPath: socketPath,
		PollInterval: 15, CacheDir: t.TempDir(), ConfigHome: t.TempDir(), RuntimeDir: t.TempDir(),
	}
	server := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	defer func() {
		if server.conversationB != nil {
			_ = server.conversationB.Close()
		}
		_ = server.hub.Shutdown(ctx)
	}()
	server.setInventoryPublisher(ctx)
	pollDone := make(chan struct{})
	go func() {
		server.poller.Run(ctx)
		close(pollDone)
	}()
	select {
	case <-firstReady:
	case <-ctx.Done():
		t.Fatal("production poll did not reach its initial successful inventory")
	}
	server.poller.Wake()
	waitForCommittedState := func(want string) {
		t.Helper()
		ticker := time.NewTicker(time.Millisecond)
		defer ticker.Stop()
		for {
			if server.committedInventoryStatus()["state"] == want {
				return
			}
			select {
			case <-ticker.C:
			case <-ctx.Done():
				t.Fatalf("committed inventory did not reach %q", want)
			}
		}
	}
	select {
	case <-degraded:
	case <-ctx.Done():
		t.Fatal("production poll did not reach its failure")
	}
	waitForCommittedState("error")
	server.poller.Wake()
	select {
	case <-degradedAgain:
	case <-ctx.Done():
		t.Fatal("production poll did not reach its repeated failure")
	}
	waitForCommittedState("error")
	server.poller.Wake()
	select {
	case <-recovered:
	case <-ctx.Done():
		t.Fatal("production poll did not reach its recovery")
	}
	waitForCommittedState("ready")
	committed := server.committedInventorySnapshot()
	if committed.status["state"] != "ready" || len(committed.agents) != 1 || len(committed.workspaces) != 1 {
		t.Fatalf("zero-listener recovered snapshot = %#v, want ready topology", committed)
	}

	connected := make(chan *transport.ClientConn, 1)
	server.hub.SetOnConnect(func(client *transport.ClientConn) {
		server.sendConnectionSnapshot(client)
		connected <- client
	})
	httpServer := httptest.NewServer(http.HandlerFunc(server.hub.HandleWebSocket))
	defer httpServer.Close()
	conn, _, err := websocket.Dial(ctx, "ws"+strings.TrimPrefix(httpServer.URL, "http"), nil)
	if err != nil {
		t.Fatal(err)
	}
	client := <-connected
	for index := 0; index < 5; index++ {
		_, data, readErr := conn.Read(ctx)
		if readErr != nil {
			t.Fatal(readErr)
		}
		var message map[string]any
		if err := json.Unmarshal(data, &message); err != nil {
			t.Fatal(err)
		}
		if index == 0 {
			inventory, ok := message["inventory"].(map[string]any)
			if !ok || inventory["state"] != "ready" {
				t.Fatalf("zero-listener handshake inventory = %#v", message)
			}
		}
		if index == 4 && (message["type"] != "inventory_status" || message["state"] != "ready") {
			t.Fatalf("zero-listener handshake status = %#v", message)
		}
	}
	conn.CloseNow()
	for server.hub.ClientCount() != 0 {
		select {
		case <-ctx.Done():
			t.Fatal("disconnected refresh client remained registered")
		default:
			time.Sleep(time.Millisecond)
		}
	}
	server.requestAgentRefresh(client)
	select {
	case <-unchanged:
	case <-ctx.Done():
		t.Fatal("unchanged production poll did not complete for disconnected refresh")
	}
	for {
		server.refreshMu.Lock()
		pending := len(server.refreshClients)
		server.refreshMu.Unlock()
		if pending == 0 {
			break
		}
		select {
		case <-ctx.Done():
			t.Fatal("disconnected refresh remained pending")
		default:
			time.Sleep(time.Millisecond)
		}
	}
	cancel()
	select {
	case <-pollDone:
	case <-time.After(time.Second):
		t.Fatal("production poller did not stop")
	}
	if err := listener.Close(); err != nil {
		t.Fatal(err)
	}
	if serveErr := <-serverDone; serveErr != nil && !fixtureConnectionTornDown(serveErr) {
		t.Fatal(serveErr)
	}
}

func TestCommittedInventorySnapshotDeepCopiesInteractionSummaries(t *testing.T) {
	server := testServer()
	interaction := &question.Interaction{
		ID: "interaction-1",
		Options: []question.Option{{
			Index:   1,
			Label:   "Keep",
			Summary: []question.SummaryEntry{{Question: "Deploy?", Answer: "No"}},
		}},
	}
	server.stateViewMu.Lock()
	server.agentView = []*coordinator.AgentState{{PaneID: "pane-1", Interaction: interaction}}
	server.stateViewMu.Unlock()

	snapshot := server.committedInventorySnapshot()
	snapshot.agents[0].Interaction.Options[0].Summary[0].Answer = "Mutated"
	fresh := server.committedInventorySnapshot()
	if got := fresh.agents[0].Interaction.Options[0].Summary[0].Answer; got != "No" {
		t.Fatalf("committed interaction summary answer = %q, want No", got)
	}
}

func TestHealth(t *testing.T) {
	s := testServer()
	req := httptest.NewRequest("GET", "/health", nil)
	w := httptest.NewRecorder()

	s.handleHealth(w, req)

	if w.Code != 200 {
		t.Fatalf("status = %d, want 200", w.Code)
	}
	if body := w.Body.String(); body != "ok\n" {
		t.Errorf("body = %q, want \"ok\\n\"", body)
	}
	if inst := w.Header().Get("X-Herdr-Relay-Instance"); inst != "test-instance" {
		t.Errorf("instance header = %q, want test-instance", inst)
	}
}

func TestPaneDeltaResponsePreservesTruncation(t *testing.T) {
	delta := paneDeltaResponse(
		map[string]any{
			"type":      "pane_content",
			"content":   "new output",
			"truncated": true,
			"format":    "ansi",
		},
		"content-1",
		nil,
	)
	if delta["truncated"] != true {
		t.Fatalf("delta truncation = %#v, want true", delta["truncated"])
	}
	if _, ok := delta["content"]; ok {
		t.Fatal("delta unexpectedly included full content")
	}
}

func TestPaneWatchUpdateSendsMetadataOnlyDelta(t *testing.T) {
	response := map[string]any{
		"type":           "pane_content",
		"content":        "unchanged\nquestion\n",
		"attention_kind": question.AttentionQuestion,
		"interaction":    map[string]any{"id": "question-1"},
	}
	previous := map[string]any{
		"type":           "pane_content",
		"content":        "unchanged\nquestion\n",
		"attention_kind": question.AttentionUnknown,
	}
	acknowledged := &paneWatchFrame{
		content:            "unchanged\nquestion\n",
		contentFingerprint: "content-1",
		frameFingerprint:   paneFrameFingerprint(previous),
	}
	current := &paneWatchFrame{
		content:            "unchanged\nquestion\n",
		contentFingerprint: "content-1",
		frameFingerprint:   paneFrameFingerprint(response),
	}
	if acknowledged.frameFingerprint == current.frameFingerprint {
		t.Fatal("question metadata did not change the pane frame fingerprint")
	}
	initial := *acknowledged
	initial.frameFingerprint = ""
	if paneWatchUpdate(response, &initial, current) == nil {
		t.Fatal("initial pane watch suppressed current interaction metadata")
	}

	update := paneWatchUpdate(response, acknowledged, current)
	if update["type"] != "pane_delta" ||
		update["base_fingerprint"] != "content-1" {
		t.Fatalf("metadata update = %#v", update)
	}
	if _, ok := update["content"]; ok {
		t.Fatal("metadata delta unexpectedly included full terminal content")
	}
	segments, ok := update["segments"].([]panedelta.Segment)
	if !ok || len(segments) != 1 || segments[0].CopyStart != 0 ||
		segments[0].CopyLines != 3 || segments[0].Text != "" {
		t.Fatalf("metadata delta segments = %#v, want one whole-frame copy", update["segments"])
	}
	applied, appliedOK := panedelta.Apply(acknowledged.content, segments)
	if !appliedOK || applied != current.content {
		t.Fatalf("metadata delta applied = %q, %v; want %q, true", applied, appliedOK, current.content)
	}
	encoded, err := json.Marshal(update)
	if err != nil {
		t.Fatalf("marshal metadata delta: %v", err)
	}
	if strings.Contains(string(encoded), `"segments":null`) {
		t.Fatalf("metadata delta encoded a null segment list: %s", encoded)
	}
}

func TestPaneWatchUpdateSendsResizeSettledDelta(t *testing.T) {
	settlingResponse := map[string]any{
		"type":            "pane_content",
		"content":         "unchanged terminal",
		"resize_settling": true,
	}
	settledResponse := map[string]any{
		"type":    "pane_content",
		"content": "unchanged terminal",
	}
	acknowledged := &paneWatchFrame{
		content:            "unchanged terminal",
		contentFingerprint: "content-1",
		frameFingerprint:   paneFrameFingerprint(settlingResponse),
		resizeSettling:     true,
	}
	current := &paneWatchFrame{
		content:            "unchanged terminal",
		contentFingerprint: "content-1",
		frameFingerprint:   paneFrameFingerprint(settledResponse),
	}
	if acknowledged.frameFingerprint == current.frameFingerprint {
		t.Fatal("resize settling state did not change the pane frame fingerprint")
	}

	if !paneWatchNeedsFrameRead("probe-1", "probe-1", acknowledged, "") {
		t.Fatal("settling pane frame would not be re-read after an unchanged probe")
	}
	if paneWatchNeedsFrameRead("probe-1", "probe-1", current, "") {
		t.Fatal("settled pane frame would be re-read after an unchanged probe")
	}
	update := paneWatchUpdate(settledResponse, acknowledged, current)
	if update["type"] != "pane_delta" ||
		update["base_fingerprint"] != "content-1" {
		t.Fatalf("resize settled update = %#v", update)
	}
	if update["resize_settling"] == true {
		t.Fatalf("resize settled update remained transient: %#v", update)
	}
}

func TestPreparePaneResponsePreservesHistoryForViewportOnlyRead(t *testing.T) {
	s := testServerWithCacheDir(t.TempDir())
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "claude", Status: "idle",
	}}, s.state.RevisionCounter())
	baseline := "history 1\nhistory 2\nhistory 3\nhistory 4\nhistory 5\nhistory 6\nhistory 7\nhistory 8"
	s.historyM.Merge("pane-1", baseline)

	response := map[string]any{
		"type": "pane_content", "pane_id": "pane-1",
		"content": "current 1\ncurrent 2", "format": "ansi",
		"truncated": false, "viewport_only": true,
	}
	s.preparePaneResponse(
		map[string]any{"pane_id": "pane-1", "lines": 100, "terminal_columns": 59},
		response,
	)

	if response["content"] != "current 1\ncurrent 2" {
		t.Fatalf("resized content = %q, want clean current viewport", response["content"])
	}
	if response["truncated"] != false {
		t.Fatalf("resized truncation = %#v, want false", response["truncated"])
	}
	if content := s.historyM.Content("pane-1", 100); content != baseline {
		t.Fatalf("history changed during resized read:\n%s", content)
	}
}

func TestCopyBlockedMessage(t *testing.T) {
	tests := []struct {
		name  string
		agent *coordinator.AgentState
		want  string
	}{
		{name: "nil", want: ""},
		{name: "working question", agent: &coordinator.AgentState{
			Status: "working", AttentionKind: question.AttentionQuestion,
		}, want: ""},
		{name: "question", agent: &coordinator.AgentState{
			Status: "blocked", AttentionKind: question.AttentionQuestion,
		}, want: "Agent is waiting for an answer"},
		{name: "approval", agent: &coordinator.AgentState{
			Status: "blocked", AttentionKind: question.AttentionApproval,
		}, want: "Agent is waiting for approval"},
		{name: "unknown blocked", agent: &coordinator.AgentState{
			Status: "blocked", AttentionKind: question.AttentionUnknown,
		}, want: ""},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := copyBlockedMessage(test.agent); got != test.want {
				t.Fatalf("copyBlockedMessage() = %q, want %q", got, test.want)
			}
		})
	}
}

func TestClassifyBlockedTransitionRetriesPartialCodexQuestion(t *testing.T) {
	partial := `
Question 1/3 (3 unanswered)
After a respondent finishes a questionnaire, what should the app do?

› 1. Builder-defined result (Recommended)  Show the configured result.
  2. Response dashboard                    Store responses for review.
  3. Personalized output                   Generate a tailored result.
  4. None of the above                     Optionally, add details in notes (tab).
`
	complete := partial + `
tab to add notes | enter to submit answer | ←/→ to navigate questions | esc to interrupt
`
	calls := 0
	classification, err := classifyBlockedTransition(
		context.Background(),
		"codex",
		func(context.Context) (string, error) {
			calls++
			if calls == 1 {
				return partial, nil
			}
			return complete, nil
		},
	)
	if err != nil {
		t.Fatal(err)
	}
	if calls != 2 ||
		classification.Kind != question.AttentionQuestion ||
		classification.Interaction == nil ||
		classification.Interaction.Question !=
			"After a respondent finishes a questionnaire, what should the app do?" {
		t.Fatalf("classification after %d reads = %+v", calls, classification)
	}
}

func TestCopyResponseError(t *testing.T) {
	tests := []struct {
		name string
		err  error
		want string
	}{
		{name: "busy composer", err: copyresponse.ErrComposerBusy, want: "The agent composer is busy; finish or clear the current prompt first"},
		{name: "open picker", err: copyresponse.ErrPickerOpen, want: "The agent already has a copy menu open; close it and try again"},
		{name: "stale output", err: copyresponse.ErrStaleOutput, want: "The copied response changed before it could be read; try again"},
		{name: "no copy", err: copyresponse.ErrNoCopy, want: "The agent did not confirm a copied response; try again"},
		{name: "timeout", err: context.DeadlineExceeded, want: "Copying the agent response timed out; try again"},
		{name: "unknown", err: errors.New("internal detail"), want: "Could not copy the agent response; try again"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := copyResponseError(test.err); got != test.want {
				t.Fatalf("copyResponseError() = %q, want %q", got, test.want)
			}
		})
	}
}
func openCopyTestClient(t *testing.T, s *Server) *websocket.Conn {
	t.Helper()
	s.hub.SetHandler(func(client *transport.ClientConn, message map[string]any, admitted func()) {
		defer admitted()
		if message["type"] != "copy_agent_response" {
			return
		}
		requestID, _ := message["request_id"].(string)
		paneID, _ := message["pane_id"].(string)
		s.copyAgentResponse(client, requestID, paneID)
	})
	server := httptest.NewServer(http.HandlerFunc(s.hub.HandleWebSocket))
	conn, _, err := websocket.Dial(context.Background(), "ws"+strings.TrimPrefix(server.URL, "http"), nil)
	if err != nil {
		server.Close()
		t.Fatalf("dial copy test client: %v", err)
	}
	t.Cleanup(func() {
		conn.CloseNow()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(shutdownCtx)
		server.Close()
	})
	return conn
}

func sendCopyRequest(t *testing.T, conn *websocket.Conn, requestID, paneID string) map[string]any {
	t.Helper()
	payload, err := json.Marshal(map[string]any{
		"type": "copy_agent_response", "request_id": requestID, "pane_id": paneID,
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := conn.Write(ctx, websocket.MessageText, payload); err != nil {
		t.Fatalf("write copy request: %v", err)
	}
	_, data, err := conn.Read(ctx)
	if err != nil {
		t.Fatalf("read copy result: %v", err)
	}
	var result map[string]any
	if err := json.Unmarshal(data, &result); err != nil {
		t.Fatalf("decode copy result: %v", err)
	}
	return result
}

func TestSpeakTextSynthesizesOverTheWire(t *testing.T) {
	s := testServer()
	synthesized := ""
	spokenLanguage := ""
	availableLanguages := []string{"en", "fr"}
	s.speechStatus = func() speech.Catalog {
		return speech.Catalog{Languages: append([]string(nil), availableLanguages...)}
	}
	s.speechSynth = func(_ context.Context, text, language string) ([]byte, error) {
		synthesized = text
		spokenLanguage = language
		if strings.Contains(text, "fail") {
			return nil, errors.New("engine detail stays server-side")
		}
		return []byte("RIFFfakewav"), nil
	}
	// Mirrors the production gate: an action missing from the protocol
	// catalog is rejected as unknown_action before any dispatch case runs.
	s.hub.SetHandler(func(client *transport.ClientConn, message map[string]any, admitted func()) {
		defer admitted()
		if message["type"] != "speak_text" {
			return
		}
		inbound, err := protocol.DecodeMap(message)
		if err != nil {
			t.Errorf("decode speak_text: %v", err)
			return
		}
		if _, known := protocol.ScopeFor(inbound); !known {
			t.Error("speak_text is not a registered protocol action")
			return
		}
		requestID, _ := message["request_id"].(string)
		speechRequestID, _ := message["speech_request_id"].(string)
		text, _ := message["text"].(string)
		language, _ := message["language"].(string)
		s.speakText(client, requestID, speechRequestID, text, language)
	})
	server := httptest.NewServer(http.HandlerFunc(s.hub.HandleWebSocket))
	conn, _, err := websocket.Dial(context.Background(), "ws"+strings.TrimPrefix(server.URL, "http"), nil)
	if err != nil {
		server.Close()
		t.Fatalf("dial speak test client: %v", err)
	}
	t.Cleanup(func() {
		conn.CloseNow()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(shutdownCtx)
		server.Close()
	})
	request := func(text, language string) map[string]any {
		t.Helper()
		payload, err := json.Marshal(map[string]any{
			"type":       "speak_text",
			"request_id": "req-1",
			"text":       text,
			"language":   language,
		})
		if err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		if err := conn.Write(ctx, websocket.MessageText, payload); err != nil {
			t.Fatalf("write speak request: %v", err)
		}
		_, data, err := conn.Read(ctx)
		if err != nil {
			t.Fatalf("read speak result: %v", err)
		}
		var result map[string]any
		if err := json.Unmarshal(data, &result); err != nil {
			t.Fatal(err)
		}
		return result
	}

	result := request("hello phone", "fr")
	data, _ := result["data"].(map[string]any)
	if result["ok"] != true || data["format"] != "wav" ||
		data["audio"] != base64.StdEncoding.EncodeToString([]byte("RIFFfakewav")) {
		t.Fatalf("speak result = %+v, want base64 wav payload", result)
	}
	if synthesized != "hello phone" || spokenLanguage != "fr" {
		t.Fatalf("synthesized %q in %q, want the requested text and language", synthesized, spokenLanguage)
	}

	// Engine details never reach the phone; the toast stays generic.
	failed := request("please fail", "en")
	if failed["ok"] != false || failed["error"] != "Speech synthesis failed on this computer" {
		t.Fatalf("failed result = %+v, want generic synthesis failure", failed)
	}

	// A language this host has no voice for is refused before synthesis.
	unsupported := request("hallo", "de")
	if unsupported["ok"] != false || unsupported["error"] != "This computer has no voice for that language" {
		t.Fatalf("unsupported language result = %+v", unsupported)
	}

	availableLanguages = nil
	missing := request("hello", "en")
	if missing["ok"] != false || missing["error"] != "No speech engine is installed on this computer" {
		t.Fatalf("missing engine result = %+v", missing)
	}
}

func TestCancelSpeechStopsRelaySynthesis(t *testing.T) {
	s := testServer()
	s.speechStatus = func() speech.Catalog {
		return speech.Catalog{Languages: []string{"en"}}
	}
	started := make(chan struct{})
	s.speechSynth = func(ctx context.Context, _, _ string) ([]byte, error) {
		close(started)
		<-ctx.Done()
		return nil, ctx.Err()
	}
	s.hub.SetHandler(func(client *transport.ClientConn, message map[string]any, admitted func()) {
		admitted()
		action, _ := message["type"].(string)
		speechRequestID, _ := message["speech_request_id"].(string)
		switch action {
		case "speak_text":
			requestID, _ := message["request_id"].(string)
			s.speakText(client, requestID, speechRequestID, "stop this", "en")
		case "cancel_speech":
			s.cancelSpeech(client.ID(), speechRequestID)
		}
	})
	server := httptest.NewServer(http.HandlerFunc(s.hub.HandleWebSocket))
	conn, _, err := websocket.Dial(context.Background(), "ws"+strings.TrimPrefix(server.URL, "http"), nil)
	if err != nil {
		server.Close()
		t.Fatalf("dial speech cancellation client: %v", err)
	}
	t.Cleanup(func() {
		conn.CloseNow()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(shutdownCtx)
		server.Close()
	})
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := conn.Write(ctx, websocket.MessageText, []byte(
		`{"type":"speak_text","request_id":"speak-1","speech_request_id":"speech-1"}`,
	)); err != nil {
		t.Fatal(err)
	}
	select {
	case <-started:
	case <-ctx.Done():
		t.Fatal("speech synthesis did not start")
	}
	if err := conn.Write(ctx, websocket.MessageText, []byte(
		`{"type":"cancel_speech","speech_request_id":"speech-1"}`,
	)); err != nil {
		t.Fatal(err)
	}
	_, data, err := conn.Read(ctx)
	if err != nil {
		t.Fatalf("read cancelled speech result: %v", err)
	}
	var result map[string]any
	if err := json.Unmarshal(data, &result); err != nil {
		t.Fatal(err)
	}
	if result["request_id"] != "speak-1" || result["ok"] != false {
		t.Fatalf("cancelled speech result = %#v", result)
	}
}

func TestSpeechVoiceManagementOverTheWire(t *testing.T) {
	s := testServer()
	installed := map[string]bool{"en": true}
	s.speechStatus = func() speech.Catalog {
		status := speech.Catalog{CacheDir: "/cache/speech", EngineInstalled: true, ManagementSupported: true}
		for _, language := range speech.Offered {
			engine := "espeak-ng"
			if installed[language] {
				engine = "piper"
				status.Languages = append(status.Languages, language)
			}
			status.Voices = append(status.Voices, speech.VoiceStatus{
				Language:  language,
				Name:      language + "-voice",
				Installed: installed[language],
				Bytes:     63 << 20,
				Engine:    engine,
			})
		}
		return status
	}
	requested := ""
	s.speechInstall = func(_ context.Context, language string) error {
		requested = language
		if language == "zh" {
			return errors.New("engine detail stays server-side")
		}
		installed[language] = true
		return nil
	}
	s.speechRemove = func(language string) error {
		delete(installed, language)
		return nil
	}
	s.hub.SetHandler(func(client *transport.ClientConn, message map[string]any, admitted func()) {
		defer admitted()
		action, _ := message["type"].(string)
		requestID, _ := message["request_id"].(string)
		language, _ := message["language"].(string)
		inbound, err := protocol.DecodeMap(message)
		if err != nil {
			t.Errorf("decode %s: %v", action, err)
			return
		}
		scope, known := protocol.ScopeFor(inbound)
		if !known {
			t.Errorf("%s is not a registered protocol action", action)
			return
		}
		switch action {
		case "speech_voices_list":
			if scope.Action.Class != protocol.ActionReadOnly {
				t.Error("listing voices must stay a read-only action")
			}
			s.sendCommandResult(client, requestID, action, true, "completed", "", "", s.speechVoicePayload(nil))
		case "speech_voice_install", "speech_voice_remove":
			if scope.Action.Class != protocol.ActionMutating {
				t.Errorf("%s must be a mutating action so readers cannot run it", action)
			}
			s.changeSpeechVoice(client, requestID, action, language)
		}
	})
	server := httptest.NewServer(http.HandlerFunc(s.hub.HandleWebSocket))
	conn, _, err := websocket.Dial(context.Background(), "ws"+strings.TrimPrefix(server.URL, "http"), nil)
	if err != nil {
		server.Close()
		t.Fatalf("dial voice test client: %v", err)
	}
	t.Cleanup(func() {
		conn.CloseNow()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(shutdownCtx)
		server.Close()
	})
	exchange := func(request map[string]any) []map[string]any {
		t.Helper()
		payload, err := json.Marshal(request)
		if err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		if err := conn.Write(ctx, websocket.MessageText, payload); err != nil {
			t.Fatalf("write %v: %v", request["type"], err)
		}
		var messages []map[string]any
		for {
			_, data, err := conn.Read(ctx)
			if err != nil {
				t.Fatalf("read %v result: %v", request["type"], err)
			}
			var message map[string]any
			if err := json.Unmarshal(data, &message); err != nil {
				t.Fatal(err)
			}
			messages = append(messages, message)
			if message["type"] == "command_result" {
				return messages
			}
		}
	}
	voiceState := func(message map[string]any) map[string]bool {
		t.Helper()
		payload, _ := message["data"].(map[string]any)
		if payload == nil {
			payload = message
		}
		voices, _ := payload["voices"].([]any)
		if len(voices) != len(speech.Offered) {
			t.Fatalf("payload lists %d voices, want %d", len(voices), len(speech.Offered))
		}
		state := map[string]bool{}
		for _, entry := range voices {
			voice, _ := entry.(map[string]any)
			language, _ := voice["language"].(string)
			state[language], _ = voice["installed"].(bool)
		}
		return state
	}

	listed := exchange(map[string]any{"type": "speech_voices_list", "request_id": "list-1"})
	result := listed[len(listed)-1]
	data, _ := result["data"].(map[string]any)
	if result["ok"] != true || data["cache_dir"] != "/cache/speech" || data["engine_installed"] != true {
		t.Fatalf("list result = %+v", result)
	}
	if state := voiceState(result); !state["en"] || state["fr"] {
		t.Fatalf("listed voices = %+v, want English only", state)
	}

	// Installing answers the caller and tells every phone what the computer
	// can speak now, so a second device is never left with a stale list.
	messages := exchange(map[string]any{"type": "speech_voice_install", "request_id": "install-1", "language": "fr", "protocol": protocol.Version})
	if requested != "fr" {
		t.Fatalf("installed language = %q, want fr", requested)
	}
	broadcast := map[string]any{}
	for _, message := range messages {
		if message["type"] == "speech_voices" {
			broadcast = message
		}
	}
	if len(broadcast) == 0 {
		t.Fatalf("install sent no speech_voices broadcast: %+v", messages)
	}
	if state := voiceState(broadcast); !state["fr"] {
		t.Fatalf("broadcast voices = %+v, want French installed", state)
	}
	if languages, _ := broadcast["languages"].([]any); len(languages) != 2 {
		t.Fatalf("broadcast languages = %+v, want English and French", broadcast["languages"])
	}
	if s.speakableLanguages()[1] != "fr" {
		t.Fatalf("relay speakable languages = %v, want French included", s.speakableLanguages())
	}

	removed := exchange(map[string]any{"type": "speech_voice_remove", "request_id": "remove-1", "language": "fr", "protocol": protocol.Version})
	if state := voiceState(removed[len(removed)-1]); state["fr"] {
		t.Fatalf("remove result = %+v, want French gone", removed[len(removed)-1])
	}

	// A failed download keeps engine details server-side and still reports the
	// unchanged catalog.
	failed := exchange(map[string]any{"type": "speech_voice_install", "request_id": "install-2", "language": "zh", "protocol": protocol.Version})
	result = failed[len(failed)-1]
	if result["ok"] != false || result["error"] != "Downloading the Chinese voice failed on this computer" {
		t.Fatalf("failed install result = %+v", result)
	}
	if state := voiceState(result); state["zh"] {
		t.Fatalf("failed install reported Chinese as installed: %+v", result)
	}

	unsupported := exchange(map[string]any{"type": "speech_voice_install", "request_id": "install-3", "language": "ja", "protocol": protocol.Version})
	result = unsupported[len(unsupported)-1]
	if result["ok"] != false || result["error"] != "That language is not one this app reads aloud" {
		t.Fatalf("unsupported language result = %+v", result)
	}
}

func TestCopyAgentResponseValidatesPaneState(t *testing.T) {
	tests := []struct {
		name    string
		paneID  string
		setup   func(*Server)
		wantErr string
	}{
		{name: "missing pane id", wantErr: "Agent is required"},
		{name: "missing pane", paneID: "missing", wantErr: "Agent pane not found"},
		{
			name:   "clipboard unavailable",
			paneID: "pane-1",
			setup: func(s *Server) {
				s.state.CommitInventory([]*coordinator.AgentState{{PaneID: "pane-1", Agent: "claude", Status: "idle"}}, s.state.RevisionCounter())
				s.clipboardRead = nil
				s.clipboardWrite = nil
			},
			wantErr: "Host clipboard is unavailable",
		},
		{
			name:   "unsupported agent",
			paneID: "pane-1",
			setup: func(s *Server) {
				s.state.CommitInventory([]*coordinator.AgentState{{PaneID: "pane-1", Agent: "unknown", Status: "idle"}}, s.state.RevisionCounter())
				s.clipboardRead = func(context.Context) ([]byte, error) { return nil, nil }
				s.clipboardWrite = func(context.Context, []byte) error { return nil }
			},
			wantErr: "Agent does not support response copying",
		},
		{
			name:   "working agent",
			paneID: "pane-1",
			setup: func(s *Server) {
				s.state.CommitInventory([]*coordinator.AgentState{{PaneID: "pane-1", Agent: "claude", Status: "working"}}, s.state.RevisionCounter())
				s.clipboardRead = func(context.Context) ([]byte, error) { return nil, nil }
				s.clipboardWrite = func(context.Context, []byte) error { return nil }
			},
			wantErr: "Agent is still working; wait for the current turn to finish",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			s := testServer()
			if test.setup != nil {
				test.setup(s)
			}
			result := sendCopyRequest(t, openCopyTestClient(t, s), test.name, test.paneID)
			if got, _ := result["error"].(string); got != test.wantErr {
				t.Fatalf("copy error = %q, want %q; response = %#v", got, test.wantErr, result)
			}
		})
	}
}

func TestCopyAgentResponseRejectsReplacedPane(t *testing.T) {
	s := testServer()
	const paneID = "pane-1"
	s.state.CommitInventory([]*coordinator.AgentState{
		{PaneID: paneID, Agent: "claude", Status: "idle", PaneRevision: 4},
	}, s.state.RevisionCounter())
	s.clipboardRead = func(context.Context) ([]byte, error) { return []byte("before"), nil }
	s.clipboardWrite = func(context.Context, []byte) error { return nil }
	s.copyRunner = func(
		_ context.Context,
		paneID string,
		_ slashcmd.CopyProfile,
		_ copyresponse.Pane,
		_ copyresponse.ClipboardReader,
		_ copyresponse.ClipboardWriter,
		_ int64,
		_ copyresponse.RevisionReader,
	) (copyresponse.Result, error) {
		s.state.BumpGeneration(paneID)
		return copyresponse.Result{Text: "response", Source: "clipboard", Chars: 8, Lines: 1}, nil
	}
	result := sendCopyRequest(t, openCopyTestClient(t, s), "replaced", paneID)
	if got, _ := result["error"].(string); got != "The agent pane was replaced while the response was being copied" {
		t.Fatalf("copy error = %q; response = %#v", got, result)
	}
}

func TestCopyAgentResponseReturnsCopiedData(t *testing.T) {
	s := testServer()
	const paneID = "pane-1"
	s.state.CommitInventory([]*coordinator.AgentState{
		{PaneID: paneID, Agent: "claude", Status: "idle", PaneRevision: 4},
	}, s.state.RevisionCounter())
	s.clipboardRead = func(context.Context) ([]byte, error) { return []byte("before"), nil }
	s.clipboardWrite = func(context.Context, []byte) error { return nil }
	s.copyRunner = func(
		context.Context,
		string,
		slashcmd.CopyProfile,
		copyresponse.Pane,
		copyresponse.ClipboardReader,
		copyresponse.ClipboardWriter,
		int64,
		copyresponse.RevisionReader,
	) (copyresponse.Result, error) {
		return copyresponse.Result{Text: "response", Source: "clipboard", Chars: 8, Lines: 1}, nil
	}
	result := sendCopyRequest(t, openCopyTestClient(t, s), "success", paneID)
	if ok, _ := result["ok"].(bool); !ok {
		t.Fatalf("copy result = %#v, want success", result)
	}
	data, _ := result["data"].(map[string]any)
	if data["text"] != "response" || data["source"] != "clipboard" {
		t.Fatalf("copy data = %#v", data)
	}
}

func TestHealthz(t *testing.T) {
	s := testServer()
	s.ready = true
	s.state.CommitInventory(nil, 0)
	req := httptest.NewRequest("GET", "/healthz", nil)
	w := httptest.NewRecorder()

	s.handleHealthz(w, req)

	if w.Code != 200 {
		t.Fatalf("status = %d, want 200", w.Code)
	}

	var resp map[string]any
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatal(err)
	}
	if resp["status"] != "ok" {
		t.Errorf("status = %v, want ok", resp["status"])
	}
	if resp["readiness"] != "ready" {
		t.Errorf("readiness = %v, want ready", resp["readiness"])
	}
	if resp["instance"] != "test-instance" {
		t.Errorf("instance = %v, want test-instance", resp["instance"])
	}
	if resp["release_version"] != "0.9.0" {
		t.Errorf("release_version = %v, want 0.9.0", resp["release_version"])
	}
	if resp["revision"] != "abc123" {
		t.Errorf("revision = %v, want abc123", resp["revision"])
	}
	if resp["protocol"] != float64(protocol.Version) {
		t.Errorf("protocol = %v, want %d", resp["protocol"], protocol.Version)
	}
	if resp["gateway_available_version"] != "0.9.0" {
		t.Errorf("gateway_available_version = %v, want 0.9.0", resp["gateway_available_version"])
	}
}

func TestReadyzIncludesReleaseIdentityForEmptyInventory(t *testing.T) {
	s := testServer()
	s.ready = true
	s.state.CommitInventory(nil, 0)
	w := httptest.NewRecorder()
	s.handleReadyz(w, httptest.NewRequest("GET", "/readyz", nil))
	var response map[string]any
	if err := json.Unmarshal(w.Body.Bytes(), &response); err != nil {
		t.Fatal(err)
	}
	if w.Code != http.StatusOK || response["status"] != "ready" || response["instance"] != "test-instance" || response["release_version"] != "0.9.0" || response["revision"] != "abc123" {
		t.Fatalf("readiness response: %d %+v", w.Code, response)
	}
	if w.Header().Get("Cache-Control") != "no-store" {
		t.Fatal("readiness may be cached")
	}
}

func TestReadyzNotReady(t *testing.T) {
	s := testServer()
	s.ready = false
	req := httptest.NewRequest("GET", "/readyz", nil)
	w := httptest.NewRecorder()

	s.handleReadyz(w, req)

	if w.Code != http.StatusServiceUnavailable {
		t.Fatalf("status = %d, want 503", w.Code)
	}

	var resp map[string]any
	json.Unmarshal(w.Body.Bytes(), &resp)
	if resp["status"] != "unavailable" {
		t.Errorf("status = %v, want unavailable", resp["status"])
	}
}

func enrollBootstrapDevice(t *testing.T, runtimeDir, token string) {
	t.Helper()
	store, err := deviceauth.Open(filepath.Join(runtimeDir, "device-auth"))
	if err != nil {
		t.Fatal(err)
	}
	if err := store.EnsureBootstrapInvitation([]byte(token), "relay", "en"); err != nil {
		t.Fatal(err)
	}
	result, err := store.CompleteE2EEAuth(context.Background(), transport.E2EEAuthSelector{
		Kind: transport.E2EEAuthInvitation, ID: "bootstrap", Version: 1, Locale: "en",
	}, true)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := store.CompleteE2EEAuth(context.Background(), transport.E2EEAuthSelector{
		Kind: transport.E2EEAuthCredential, ID: result.Identity.CredentialID,
		Version: result.Identity.CredentialVersion, Locale: result.Identity.Locale,
	}, true); err != nil {
		t.Fatal(err)
	}
}

func TestRearmedLaunchStartsWithoutStrandedDevices(t *testing.T) {
	token := strings.Repeat("k", 32)
	for _, test := range []struct {
		name    string
		rearm   bool
		devices int
	}{
		{name: "quick tunnel forgets devices stranded under the previous hostname", rearm: true, devices: 0},
		{name: "stable install keeps its paired devices", rearm: false, devices: 1},
	} {
		t.Run(test.name, func(t *testing.T) {
			root := t.TempDir()
			runtimeDir := filepath.Join(root, "runtime")
			enrollBootstrapDevice(t, runtimeDir, token)
			cfg := &config.Config{
				Token:          token,
				RearmBootstrap: test.rearm,
				RuntimeDir:     runtimeDir,
				CacheDir:       filepath.Join(root, "cache"),
			}
			s := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
			if s.deviceAuth == nil {
				t.Fatal("device store was not initialized")
			}
			if got := len(s.deviceAuth.ListCredentials("")); got != test.devices {
				t.Fatalf("paired devices after launch = %d, want %d", got, test.devices)
			}
		})
	}
}

func TestServerRunAndShutdown(t *testing.T) {
	root := t.TempDir()
	webRoot := filepath.Join(root, "web")
	if err := os.MkdirAll(webRoot, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(webRoot, "index.html"), []byte("<html></html>"), 0o600); err != nil {
		t.Fatal(err)
	}
	cfg := &config.Config{
		Host:        "127.0.0.1",
		Port:        18999,
		InstanceID:  "shutdown-test",
		WebRoot:     webRoot,
		RuntimeDir:  filepath.Join(root, "runtime"),
		CacheDir:    filepath.Join(root, "cache"),
		ConfigHome:  filepath.Join(root, "config"),
		ReleaseRoot: filepath.Join(root, "release"),
	}
	s := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- s.Run(ctx) }()

	// One second of polling is not a startup budget on a loaded CI runner under
	// -race, and a server that died immediately should say so instead of timing
	// out with a connection refused.
	deadline := time.Now().Add(15 * time.Second)
	var resp *http.Response
	var err error
	for time.Now().Before(deadline) {
		select {
		case runErr := <-done:
			t.Fatalf("Run returned before the server answered: %v", runErr)
		default:
		}
		if resp, err = http.Get("http://127.0.0.1:18999/health"); err == nil {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	if err != nil {
		t.Fatalf("server did not answer /health within 15s: %v", err)
	}
	resp.Body.Close()

	pid, err := os.ReadFile(filepath.Join(cfg.RuntimeDir, "relay.pid"))
	if err != nil || strings.TrimSpace(string(pid)) != strconv.Itoa(os.Getpid()) {
		t.Fatalf("relay.pid = %q, %v; want this process id", pid, err)
	}

	cancel()
	if err := <-done; err != nil {
		t.Fatalf("Run returned error: %v", err)
	}
	if _, err := os.Stat(filepath.Join(cfg.RuntimeDir, "relay.pid")); !os.IsNotExist(err) {
		t.Fatalf("relay.pid survives shutdown: %v", err)
	}
}

func TestArmBootstrapInvitationPairsOneMoreDevice(t *testing.T) {
	token := strings.Repeat("k", 32)
	root := t.TempDir()
	runtimeDir := filepath.Join(root, "runtime")
	enrollBootstrapDevice(t, runtimeDir, token)
	cfg := &config.Config{
		Token:      token,
		RuntimeDir: runtimeDir,
		CacheDir:   filepath.Join(root, "cache"),
	}
	s := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	if s.deviceAuth == nil {
		t.Fatal("device store was not initialized")
	}
	if _, err := s.deviceAuth.ResolveE2EESecret(context.Background(), transport.E2EEAuthSelector{
		Kind: transport.E2EEAuthInvitation, ID: "bootstrap", Version: 1,
	}); err == nil {
		t.Fatal("a consumed bootstrap still resolved before the re-arm")
	}

	if got := s.armBootstrapInvitation(); got != "armed for one more device" {
		t.Fatalf("armBootstrapInvitation() = %q", got)
	}
	if _, err := s.deviceAuth.CompleteE2EEAuth(context.Background(), transport.E2EEAuthSelector{
		Kind: transport.E2EEAuthInvitation, ID: "bootstrap", Version: 1,
	}, true); err != nil {
		t.Fatalf("second device could not pair after the re-arm: %v", err)
	}
	if got := len(s.deviceAuth.ListCredentials("")); got != 2 {
		t.Fatalf("paired devices = %d, want the first one kept plus the new one", got)
	}
}

func TestRecentSafeErrorsAreBoundedAndSingleLine(t *testing.T) {
	s := testServer()
	for index := 0; index < 25; index++ {
		s.recordSafeError("component failed", errors.New("safe\nmessage"))
	}
	recent := s.recentSafeErrors()
	if len(recent) != 20 {
		t.Fatalf("recent errors = %d, want 20", len(recent))
	}
	for _, message := range recent {
		if strings.Contains(message, "\n") || !strings.Contains(message, "component failed: safe message") {
			t.Fatalf("unsafe recent error = %q", message)
		}
	}
}

func TestRequestedPaneWatchInterval(t *testing.T) {
	tests := []struct {
		name  string
		value any
		want  time.Duration
	}{
		{name: "fast", value: float64(100), want: 100 * time.Millisecond},
		{name: "default", value: float64(250), want: 250 * time.Millisecond},
		{name: "balanced battery", value: float64(500), want: 500 * time.Millisecond},
		{name: "slow", value: float64(1_000), want: time.Second},
		{name: "missing", value: nil, want: defaultPaneWatchInterval},
		{name: "unsupported", value: float64(333), want: defaultPaneWatchInterval},
		{name: "fractional", value: 100.5, want: defaultPaneWatchInterval},
		{name: "wrong type", value: "100", want: defaultPaneWatchInterval},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := requestedPaneWatchInterval(test.value); got != test.want {
				t.Fatalf("requestedPaneWatchInterval(%v) = %s, want %s", test.value, got, test.want)
			}
		})
	}
}

func TestCommittedActivityViewTracksLiveCommitAndClear(t *testing.T) {
	s := testServer()
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(ctx)
	})
	entry := activity.NewEntry("prompt", "sent", "hello", "pane-1", "", "", "request-1")
	s.broadcastCommitted(map[string]any{"type": "activity", "activity": entry})
	recent := s.recentActivities(500)
	if len(recent) != 1 || recent[0].ID != entry.ID {
		t.Fatalf("committed view = %+v", recent)
	}
	s.broadcastCommitted(map[string]any{"type": "activity_history", "activities": []activity.Entry{}})
	if recent := s.recentActivities(500); len(recent) != 0 {
		t.Fatalf("cleared view = %+v", recent)
	}
}

func TestCommittedStateViewTracksSnapshotsAndDeltas(t *testing.T) {
	s := testServer()
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(ctx)
	})
	s.broadcastCommitted(map[string]any{
		"type": "agents",
		"agents": []*coordinator.AgentState{{
			PaneID: "pane-1", Status: "blocked", Project: "project",
			BlockedEventID: "event-1", AttentionKind: question.AttentionApproval,
			Options: []string{"Approve", "Deny"}, ApprovalFingerprint: "approval-fingerprint-1",
		}},
	})
	s.broadcastCommitted(map[string]any{
		"type": "agent_update", "pane_id": "pane-1", "status": "blocked", "project": "renamed",
	})
	agents := s.committedAgents()
	if len(agents) != 1 || agents[0].Status != "blocked" ||
		agents[0].BlockedEventID != "event-1" ||
		agents[0].ApprovalFingerprint != "approval-fingerprint-1" {
		t.Fatalf("committed agents = %+v", agents)
	}
	s.broadcastCommitted(map[string]any{
		"type": "inventory_status", "state": "ready", "stale": false,
	})
	inventory := s.committedInventoryStatus()
	if inventory["state"] != "ready" || inventory["stale"] != false {
		t.Fatalf("committed inventory = %+v", inventory)
	}
	if _, leaked := inventory["type"]; leaked {
		t.Fatalf("inventory view leaked transport type: %+v", inventory)
	}
}

func TestCommittedStateViewRejectsStalePerPaneUpdates(t *testing.T) {
	s := testServer()
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = s.hub.Shutdown(ctx)
	})
	s.broadcastCommitted(map[string]any{
		"type": "agents",
		"agents": []*coordinator.AgentState{{
			PaneID: "pane-1", Status: "working", StateRevision: 12,
		}},
	})
	s.broadcastCommitted(map[string]any{
		"type": "agent_update", "pane_id": "pane-1", "status": "blocked",
		"event_id": "stale-event", "pane_revision": int64(11),
	})
	s.broadcastCommitted(map[string]any{
		"type": "agents",
		"agents": []*coordinator.AgentState{{
			PaneID: "pane-1", Status: "blocked", BlockedEventID: "stale-snapshot", StateRevision: 10,
		}},
	})

	agents := s.committedAgents()
	if len(agents) != 1 || agents[0].Status != "working" ||
		agents[0].StateRevision != 12 || agents[0].BlockedEventID != "" {
		t.Fatalf("reconnect snapshot regressed after stale messages: %+v", agents)
	}
}

type blockingTransitionPush struct {
	started chan struct{}
	release chan struct{}
	cancel  chan struct{}
}

func (p *blockingTransitionPush) Send(ctx context.Context, _ []byte) {
	close(p.started)
	select {
	case <-p.release:
	case <-ctx.Done():
		if p.cancel != nil {
			close(p.cancel)
		}
	}
}

type recordingTransitionBroadcast struct {
	messages chan any
}

func (b *recordingTransitionBroadcast) Broadcast(message any) {
	b.messages <- message
}

type recordingTransitionPush struct {
	messages chan []byte
}

func (p *recordingTransitionPush) Send(_ context.Context, payload []byte) {
	p.messages <- payload
}

func TestUnchangedPollPreservesBlockedTransitionSideEffects(t *testing.T) {
	root := t.TempDir()
	s := testServer()
	journal, err := activity.OpenJournal(filepath.Join(root, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	s.dispatcher = coordinator.NewDispatcher(nil, s.state, journal, s.logger)
	t.Cleanup(func() {
		_ = s.dispatcher.Close(context.Background())
	})
	push := &recordingTransitionPush{messages: make(chan []byte, 2)}
	broadcast := &recordingTransitionBroadcast{messages: make(chan any, 2)}
	s.transitionPush = push
	s.transitionBroadcast = broadcast
	enrichStarted := make(chan struct{})
	enrichRelease := make(chan struct{})
	s.transitionEnrich = func(_ context.Context, agent *coordinator.AgentState) {
		close(enrichStarted)
		<-enrichRelease
		agent.AttentionKind = "approval"
		agent.Command = "Approve deployment"
		agent.Prompt = "Allow this command?"
		agent.Options = []string{"Approve", "Reject"}
	}
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "codex", Project: "relay", Status: "working",
	}}, s.state.RevisionCounter())
	s.state.CommitEvent("pane-1", "blocked", time.Now().UnixMilli())
	revision := s.state.Revision("pane-1")

	done := make(chan struct{})
	go func() {
		s.handleTransition(context.Background(), "pane-1", "codex", "relay", "blocked", revision)
		close(done)
	}()
	<-enrichStarted
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "codex", Project: "relay", Status: "blocked",
	}}, s.state.RevisionCounter())
	close(enrichRelease)
	<-done

	if entries := journal.Recent(10); len(entries) != 1 ||
		entries[0].Kind != "blocked" || entries[0].Summary != "Approve deployment" {
		t.Fatalf("blocked activity entries = %+v, want exactly one enriched entry", entries)
	}
	if len(push.messages) != 1 {
		t.Fatalf("blocked pushes = %d, want exactly one", len(push.messages))
	}
	if len(broadcast.messages) != 1 {
		t.Fatalf("blocked broadcasts = %d, want exactly one", len(broadcast.messages))
	}
}

func TestBlockedBroadcastDoesNotOvertakeNewerWorkingState(t *testing.T) {
	s := testServer()
	push := &blockingTransitionPush{
		started: make(chan struct{}), release: make(chan struct{}), cancel: make(chan struct{}),
	}
	broadcast := &recordingTransitionBroadcast{messages: make(chan any, 1)}
	s.transitionPush = push
	s.transitionBroadcast = broadcast
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "codex", Project: "relay", Status: "working",
	}}, s.state.RevisionCounter())
	s.state.CommitEvent("pane-1", "blocked", time.Now().UnixMilli())
	revision := s.state.Revision("pane-1")

	done := make(chan struct{})
	go func() {
		s.handleTransition(context.Background(), "pane-1", "codex", "relay", "blocked", revision)
		close(done)
	}()
	<-push.started

	s.state.CommitEvent("pane-1", "working", time.Now().UnixMilli())
	select {
	case <-push.cancel:
	case <-time.After(time.Second):
		t.Fatal("stale blocked push request was not canceled")
	}
	<-done

	select {
	case message := <-broadcast.messages:
		t.Fatalf("stale blocked transition was broadcast after working revision: %#v", message)
	default:
	}
}

func TestApprovalPushCanceledWhenAttentionIsReclassified(t *testing.T) {
	s := testServer()
	push := &blockingTransitionPush{
		started: make(chan struct{}), release: make(chan struct{}), cancel: make(chan struct{}),
	}
	broadcast := &recordingTransitionBroadcast{messages: make(chan any, 1)}
	s.transitionPush = push
	s.transitionBroadcast = broadcast
	s.transitionEnrich = func(_ context.Context, agent *coordinator.AgentState) {
		agent.AttentionKind = question.AttentionApproval
		agent.Command = "Approve deployment"
		agent.Prompt = "Allow this command?"
		agent.Options = []string{"Approve", "Reject"}
	}
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "codex", Project: "relay", Status: "working",
	}}, s.state.RevisionCounter())
	s.state.CommitEvent("pane-1", "blocked", time.Now().UnixMilli())
	revision := s.state.Revision("pane-1")

	done := make(chan struct{})
	go func() {
		s.handleTransition(context.Background(), "pane-1", "codex", "relay", "blocked", revision)
		close(done)
	}()
	<-push.started

	agent, ok := s.state.Agent("pane-1")
	if !ok {
		t.Fatal("blocked agent disappeared")
	}
	generation, active := s.state.PaneSession("pane-1")
	if !active {
		t.Fatal("blocked pane session disappeared")
	}
	if _, committed := s.state.CommitAttentionClassification(
		"pane-1",
		agent.BlockedEventID,
		uint64(generation),
		s.state.ContentRevision("pane-1"),
		question.Classification{
			Kind:   question.AttentionChat,
			Prompt: "What would you like to work on next?",
		},
	); !committed {
		t.Fatal("chat reclassification was not committed")
	}
	select {
	case <-push.cancel:
	case <-time.After(time.Second):
		t.Fatal("reclassified approval push request was not canceled")
	}
	<-done

	select {
	case message := <-broadcast.messages:
		t.Fatalf("stale approval was broadcast after reclassification: %#v", message)
	default:
	}
}

func TestChatClassificationUsesOneCompletionPath(t *testing.T) {
	root := t.TempDir()
	s := testServer()
	journal, err := activity.OpenJournal(filepath.Join(root, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	s.dispatcher = coordinator.NewDispatcher(nil, s.state, journal, s.logger)
	t.Cleanup(func() {
		_ = s.dispatcher.Close(context.Background())
	})
	push := &recordingTransitionPush{messages: make(chan []byte, 3)}
	broadcast := &recordingTransitionBroadcast{messages: make(chan any, 3)}
	s.transitionPush = push
	s.transitionBroadcast = broadcast
	s.transitionEnrich = func(_ context.Context, agent *coordinator.AgentState) {
		agent.AttentionKind = "chat"
		agent.Prompt = "Hello! What would you like to work on next?"
		agent.Options = []string{"fabricated", "controls"}
	}
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "codex", Project: "relay", Status: "working",
	}}, s.state.RevisionCounter())
	s.state.CommitEvent("pane-1", "blocked", time.Now().UnixMilli())
	s.handleTransition(
		context.Background(), "pane-1", "codex", "relay", "blocked",
		s.state.Revision("pane-1"),
	)

	entries := journal.Recent(10)
	if len(entries) != 1 || entries[0].Kind != "finished" ||
		entries[0].Extract != "Hello! What would you like to work on next?" {
		t.Fatalf("chat activities = %+v, want one completion", entries)
	}
	if len(push.messages) != 1 {
		t.Fatalf("chat pushes = %d, want one completion push", len(push.messages))
	}
	var payload map[string]any
	if err := json.Unmarshal(<-push.messages, &payload); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(fmt.Sprint(payload["title"]), "finished") ||
		len(payload["actions"].([]any)) != 0 {
		t.Fatalf("chat push = %+v", payload)
	}
	message := (<-broadcast.messages).(map[string]any)
	if fmt.Sprint(message["attention_kind"]) != "chat" {
		t.Fatalf("chat broadcast = %+v", message)
	}
	if options, ok := message["options"].([]string); ok && len(options) != 0 {
		t.Fatalf("chat broadcast retained controls: %+v", message)
	}

	s.state.CommitEvent("pane-1", "idle", time.Now().UnixMilli())
	s.handleTransition(
		context.Background(), "pane-1", "codex", "relay", "idle",
		s.state.Revision("pane-1"),
	)
	if len(journal.Recent(10)) != 1 || len(push.messages) != 0 {
		t.Fatal("raw idle duplicated the classified chat completion")
	}
}

func TestUnknownClassificationHasNoNotificationActions(t *testing.T) {
	root := t.TempDir()
	s := testServer()
	journal, err := activity.OpenJournal(filepath.Join(root, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	s.dispatcher = coordinator.NewDispatcher(nil, s.state, journal, s.logger)
	t.Cleanup(func() {
		_ = s.dispatcher.Close(context.Background())
	})
	push := &recordingTransitionPush{messages: make(chan []byte, 1)}
	s.transitionPush = push
	s.transitionBroadcast = &recordingTransitionBroadcast{messages: make(chan any, 1)}
	s.transitionEnrich = func(_ context.Context, agent *coordinator.AgentState) {
		agent.AttentionKind = "unknown"
		agent.Prompt = "Agent needs inspection"
		agent.Options = []string{"Approve", "Reject"}
	}
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "opencode", Project: "relay", Status: "working",
	}}, s.state.RevisionCounter())
	s.state.CommitEvent("pane-1", "blocked", time.Now().UnixMilli())
	s.handleTransition(
		context.Background(), "pane-1", "opencode", "relay", "blocked",
		s.state.Revision("pane-1"),
	)

	var payload map[string]any
	if err := json.Unmarshal(<-push.messages, &payload); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(fmt.Sprint(payload["title"]), "needs inspection") ||
		len(payload["actions"].([]any)) != 0 {
		t.Fatalf("unknown push = %+v", payload)
	}
	agent, _ := s.state.Agent("pane-1")
	if len(agent.Options) != 0 || agent.Interaction != nil {
		t.Fatalf("unknown classification retained controls: %+v", agent)
	}
}

func TestBackgroundClaudeHistoryCaptureDoesNotRequirePhoneRead(t *testing.T) {
	root := t.TempDir()
	fakeHerdr := filepath.Join(root, "herdr")
	script := "#!/bin/sh\nprintf 'first output\\nsecond output\\nfooter 1\\nfooter 2\\nfooter 3\\nfooter 4\\nfooter 5\\nfooter 6\\n'\n"
	if err := os.WriteFile(fakeHerdr, []byte(script), 0o700); err != nil {
		t.Fatal(err)
	}
	if _, err := exec.Command(fakeHerdr, "--version").Output(); err != nil {
		t.Fatal(err)
	}
	cfg := &config.Config{
		HerdrBin:   fakeHerdr,
		CacheDir:   filepath.Join(root, "cache"),
		RuntimeDir: filepath.Join(root, "runtime"),
	}
	s := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	s.historyTasks = newLifecycleTasks(context.Background())
	defer s.historyTasks.Stop()
	s.state.CommitInventory([]*coordinator.AgentState{{
		PaneID: "pane-1", Agent: "Claude Code", Status: "working",
	}}, s.state.RevisionCounter())
	s.syncHistoryPanes(s.state.Snapshot())

	s.scheduleHistoryCapture(context.Background(), "pane-1")
	deadline := time.Now().Add(5 * time.Second)
	for !strings.Contains(s.historyM.Content("pane-1", 100), "second output") {
		if time.Now().After(deadline) {
			t.Fatal("background capture did not persist Claude pane output")
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func TestRemovedPaneHistoryIsDiscarded(t *testing.T) {
	root := t.TempDir()
	cfg := &config.Config{
		CacheDir:   filepath.Join(root, "cache"),
		RuntimeDir: filepath.Join(root, "runtime"),
	}
	s := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	s.historyM.Merge("pane-1", "one\ntwo\nthree\nfour\nfive\nsix\nseven")
	s.historyCaptureMu.Lock()
	s.historyActive["pane-1"] = true
	s.historyLast["pane-1"] = time.Now()
	s.historyCaptureMu.Unlock()

	s.syncHistoryPanes(nil)

	s.historyCaptureMu.Lock()
	_, active := s.historyActive["pane-1"]
	_, last := s.historyLast["pane-1"]
	s.historyCaptureMu.Unlock()
	if active || last {
		t.Fatalf("removed pane tracking remains: active=%v last=%v", active, last)
	}
	files, err := filepath.Glob(filepath.Join(cfg.CacheDir, "claude-history", "*.json"))
	if err != nil {
		t.Fatal(err)
	}
	if len(files) != 0 {
		t.Fatalf("removed pane history files remain: %v", files)
	}
}

func TestFirstInventoryReconcilesHistoryFromEarlierProcess(t *testing.T) {
	root := t.TempDir()
	cfg := &config.Config{
		CacheDir:   filepath.Join(root, "cache"),
		RuntimeDir: filepath.Join(root, "runtime"),
	}
	earlier := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	earlier.historyM.Merge("removed-pane", "one\ntwo\nthree\nfour\nfive\nsix\nseven")
	earlier.historyM.SaveAll()

	restarted := New(cfg, "0.9.0", "abc123", slog.New(slog.NewTextHandler(io.Discard, nil)))
	restarted.syncHistoryPanes([]*coordinator.AgentState{{
		PaneID: "active-pane",
		Agent:  "Claude Code",
		Status: "working",
	}})

	files, err := filepath.Glob(filepath.Join(cfg.CacheDir, "claude-history", "*.json"))
	if err != nil {
		t.Fatal(err)
	}
	if len(files) != 0 {
		t.Fatalf("stale history from earlier process remains: %v", files)
	}
}

func TestUnchangedPaneResponseSuppressesTerminalContent(t *testing.T) {
	response := map[string]any{
		"request_id": "identified-read",
		"type":       "pane_content",
		"pane_id":    "w1:p1",
		"content":    "unchanged output",
		"format":     "ansi",
		"target": protocol.TargetRef{
			ServerSessionID: "primary",
			PaneID:          "w1:p1",
			TerminalID:      "terminal-w1:p1",
			Generation:      4,
		},
	}
	fingerprint := paneFingerprint("unchanged output")
	unchanged := unchangedPaneResponse(
		map[string]any{"content_fingerprint": fingerprint},
		response,
	)
	if unchanged == nil {
		t.Fatal("matching terminal content was not suppressed")
	}
	if unchanged["type"] != "pane_unchanged" || unchanged["pane_id"] != "w1:p1" {
		t.Fatalf("unexpected unchanged response: %#v", unchanged)
	}
	if unchanged["target"] != response["target"] {
		t.Fatalf("unchanged response lost exact target: %#v", unchanged)
	}
	if unchanged["request_id"] != response["request_id"] {
		t.Fatalf("unchanged response lost read identity: %#v", unchanged)
	}
	if _, included := unchanged["content"]; included {
		t.Fatalf("unchanged response included terminal content: %#v", unchanged)
	}
	if response["content_fingerprint"] != fingerprint {
		t.Fatalf("full response fingerprint = %v, want %s", response["content_fingerprint"], fingerprint)
	}

	changed := unchangedPaneResponse(
		map[string]any{"content_fingerprint": "older"},
		response,
	)
	if changed != nil {
		t.Fatalf("changed terminal content was suppressed: %#v", changed)
	}
}
