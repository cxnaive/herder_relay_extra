import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/svelte';
import { afterAll, afterEach } from 'vitest';

// Only release-producer tests use the Node host. These globals support legacy
// setup below, not rendering or screen helpers in that host.
if (typeof HTMLDialogElement === 'undefined') {
  const { default: environment } = await import('./fixtures/vite-config-environment.mjs');
  const dom = await environment.setup(globalThis, {});
  afterAll(() => dom.teardown(globalThis));
}

function createMemoryStorage(): Storage {
  const data = new Map<string, string>();
  return {
    get length() { return data.size; },
    clear() { data.clear(); },
    getItem(key: string) { return data.has(key) ? data.get(key)! : null; },
    key(index: number) { return [...data.keys()][index] ?? null; },
    removeItem(key: string) { data.delete(key); },
    setItem(key: string, value: string) { data.set(key, String(value)); },
  };
}

// Node may expose experimental storage globals that differ by launch flags.
// Always use one deterministic in-memory implementation for unit tests.
Object.defineProperty(globalThis, 'localStorage', { value: createMemoryStorage(), configurable: true, writable: true });
Object.defineProperty(globalThis, 'sessionStorage', { value: createMemoryStorage(), configurable: true, writable: true });

const heldLocks = new Set<string>();
Object.defineProperty(navigator, 'locks', { configurable: true, value: {
  async request(name: string, options: LockOptions, action: (lock: Lock | null) => unknown) {
    if (!options.ifAvailable) throw new Error('Synthetic lock requires nonblocking acquisition');
    if (heldLocks.has(name)) return action(null);
    heldLocks.add(name);
    try { return await action({ name, mode: 'exclusive' }); }
    finally { heldLocks.delete(name); }
  },
} });

if (!HTMLDialogElement.prototype.showModal) {
  HTMLDialogElement.prototype.showModal = function showModal() {
    this.setAttribute('open', '');
  };
}

if (!HTMLDialogElement.prototype.close) {
  HTMLDialogElement.prototype.close = function close() {
    this.removeAttribute('open');
    this.dispatchEvent(new Event('close'));
  };
}

afterEach(() => {
  cleanup();
  localStorage.clear();
  sessionStorage.clear();
  history.replaceState(null, '', '/');
});
