<script lang="ts">
  import { createReorderHold } from '$lib/reorder-hold';
  import { displacedSlot, insertionSlot, slotGap, type ReorderSlot } from '$lib/reorder-geometry';
  import { onMount } from 'svelte';
  import AgentLogo, { agentDisplayName, hasAgentLogo } from '$components/AgentLogo.svelte';
  import PairDeferredRelay from '$components/PairDeferredRelay.svelte';
  import Button from '$components/ui/Button.svelte';
  import {
    agentLastActiveAt,
    agentStatusGroup,
    agentStatusTone,
    approvalButtonTone,
    approvalOptions,
    approvalPromptPreview,
    displayName,
    hostLabel,
    questionInteraction,
    sortedAgents,
    tabName,
  } from '$lib/agents';
  import { hiddenServers, homeLayout, setServerHidden } from '$lib/preferences';
  import { answerFailureToast, returnedInteraction } from '$lib/questions';
  import { relayStore, type CommandError } from '$lib/store';
  import type { Agent, QuestionInteraction, RelayConfig, RelayConnectionView, RelayWorkspace } from '$lib/types';
  import { homeRelativePath, informativePath, workspaceGroupTrees, workspaceGroups, workspaceIdentity, workspaceProvenance, workspaceStateTone, type WorkspaceGroup, type WorkspaceGroupTree, type WorkspaceTab } from '$lib/workspaces';

  let {
    agents: allAgents,
    relays: allRelays,
    connections = new Map(),
    workspaces: allWorkspaces = [],
    workspaceDisclosure = $bindable<Record<string, boolean>>({}),
    responding,
    onopen,
  }: {
    agents: Agent[];
    relays: RelayConfig[];
    workspaces?: RelayWorkspace[];
    connections?: Map<string, RelayConnectionView>;
    workspaceDisclosure?: Record<string, boolean>;
    responding: Set<string>;
    onopen: (agent: Agent) => void;
  } = $props();

  const serverFilterVisible = $derived(allRelays.length > 1);
  const hidden = $derived(serverFilterVisible ? $hiddenServers : []);
  const relays = $derived(allRelays.filter((relay) => !hidden.includes(relay.id)));
  const agents = $derived(allAgents.filter((agent) => !hidden.includes(agent.relay_id)));
  const workspaces = $derived(allWorkspaces.filter((workspace) => !hidden.includes(workspace.relay_id)));

  // try/catch rather than URL.canParse, which needs Safari 17.
  function urlHost(url: string): string {
    try {
      return new URL(url).host;
    } catch {
      return '';
    }
  }

  function serverFilterLabel(relay: RelayConfig): string {
    const label = relay.label || relay.id;
    if (allRelays.filter((other) => other.label === relay.label).length < 2) return label;
    return `${label} (${urlHost(relay.url) || relay.id})`;
  }

  function hiddenNeedsAttention(relayId: string): number {
    if (!hidden.includes(relayId)) return 0;
    return allAgents.filter((agent) => agent.relay_id === relayId && ['blocked', 'attention'].includes(agentStatusGroup(agent))).length;
  }

  const unavailableRelays = $derived(relays.filter((relay) => {
    const connection = connections.get(relay.id);
    return connection?.status === 'connected' && connection.inventory.state === 'error';
  }));
  const startingRelays = $derived(relays.filter((relay) => {
    const connection = connections.get(relay.id);
    return connection?.status === 'connected' && connection.inventory.state === 'starting';
  }));
  const readyRelays = $derived(relays.filter((relay) => {
    const connection = connections.get(relay.id);
    return connection?.status === 'connected' && connection.inventory.state === 'ready';
  }));
  const deferredRelays = $derived(relays.filter((relay) => connections.get(relay.id)?.pairingDeferred));

  const statusDefinitions = [
    ['attention', 'Needs inspection', 'warning'],
    ['blocked', 'Needs input', 'danger'],
  ] as const;
  let relativeNow = $state(Date.now());
  let movingTab = $state('');
  let tabDrag = $state<{
    owner: HTMLElement;
    workspaceKey: string;
    sourceTabId: string;
    pointerId: number;
    startY: number;
    deltaY: number;
    insertIdx: number;
    items: ReorderSlot[];
    gap: number;
  } | null>(null);
  // Optimistic arrangement applied between releasing a drag and the relay
  // confirming the new order, so tabs never snap back while Herdr catches up.
  let pendingTabOrder = $state<{ key: string; order: string[] } | null>(null);
  const backgroundAgents = $derived(agents.filter((agent) => {
    const group = agentStatusGroup(agent);
    return group !== 'blocked' && group !== 'attention';
  }));
  const workingAgents = $derived(backgroundAgents.filter((agent) => agentStatusGroup(agent) === 'working'));
  const doneAgents = $derived(backgroundAgents.filter((agent) => agentStatusGroup(agent) === 'done'));
  const mixedLayout = $derived($homeLayout === 'mixed');
  const doneWorkspaces = $derived(mixedLayout ? [] : workspaceGroupTrees(workspaceGroups(
    doneAgents,
    workspaceRecordsFor(doneAgents, false),
  )));
  const workingWorkspaces = $derived(mixedLayout ? [] : workspaceGroupTrees(workspaceGroups(
    workingAgents,
    workspaceRecordsFor(workingAgents, false),
  )));
  const idleAgents = $derived(backgroundAgents.filter((agent) => {
    const group = agentStatusGroup(agent);
    return group !== 'working' && group !== 'done';
  }));
  const idleWorkspaces = $derived(mixedLayout ? [] : workspaceGroupTrees(workspaceGroups(
    idleAgents,
    workspaceRecordsFor(idleAgents, true),
  )));
  const mixedWorkspaces = $derived(mixedLayout
    ? workspaceGroupTrees(workspaceGroups(backgroundAgents, workspaceRecordsFor(backgroundAgents, true)))
    : []);

  function workspaceRecordsFor(visible: Agent[], includeEmpty: boolean): RelayWorkspace[] {
    const visibleKeys = new Set(visible.map((agent) => workspaceIdentity(agent)));
    const occupiedKeys = new Set(agents.map((agent) => workspaceIdentity(agent)));
    // A linked worktree whose repository workspace is not open on the same
    // relay has no parent card to nest under (relayWorkspaceTrees renders it
    // top-level), so an empty one must stay visible in its own right.
    const orphanLinkedWorktree = (workspace: RelayWorkspace): boolean => {
      const worktree = workspace.worktree;
      if (worktree?.is_linked_worktree !== true) return false;
      if (!worktree.repo_key) return true;
      return !workspaces.some((candidate) => (
        candidate.relay_id === workspace.relay_id
        && candidate.worktree?.repo_key === worktree.repo_key
        && candidate.worktree.is_linked_worktree === false
      ));
    };
    const selected = new Set(workspaces.filter((workspace) => {
      const key = `${workspace.relay_id}\u0000${workspace.workspace_id}`;
      const unoccupiedTopLevel = includeEmpty
        && !occupiedKeys.has(key)
        && (workspace.worktree?.is_linked_worktree !== true || orphanLinkedWorktree(workspace));
      return visibleKeys.has(key) || unoccupiedTopLevel;
    }).map((workspace) => `${workspace.relay_id}\u0000${workspace.workspace_id}`));
    for (const workspace of workspaces) {
      const key = `${workspace.relay_id}\u0000${workspace.workspace_id}`;
      const worktree = workspace.worktree;
      if (!worktree?.repo_key) continue;
      if (worktree.is_linked_worktree && selected.has(key)) {
        const parent = workspaces.find((candidate) => (
          candidate.relay_id === workspace.relay_id
          && candidate.worktree?.repo_key === worktree.repo_key
          && candidate.worktree.is_linked_worktree === false
        ));
        if (parent) selected.add(`${parent.relay_id}\u0000${parent.workspace_id}`);
      } else if (!worktree.is_linked_worktree && selected.has(key)) {
        for (const child of workspaces) {
          const childKey = `${child.relay_id}\u0000${child.workspace_id}`;
          if (child.relay_id === workspace.relay_id
            && child.worktree?.repo_key === worktree.repo_key
            && child.worktree.is_linked_worktree
            && !occupiedKeys.has(childKey)) {
            selected.add(childKey);
          }
        }
      }
    }
    return workspaces.filter((workspace) => selected.has(`${workspace.relay_id}\u0000${workspace.workspace_id}`));
  }

  $effect(() => {
    if (!pendingTabOrder) return;
    const pending = pendingTabOrder;
    const workspace = [...doneWorkspaces, ...workingWorkspaces, ...idleWorkspaces, ...mixedWorkspaces]
      .flatMap((tree) => [tree.workspace, ...tree.children])
      .find((group) => group.key === pending.key);
    if (!workspace || workspace.tabs.map((tab) => tab.id).join('\u0000') === pending.order.join('\u0000')) {
      pendingTabOrder = null;
    }
  });

  function displayTabs(workspace: WorkspaceGroup): WorkspaceTab[] {
    if (pendingTabOrder?.key !== workspace.key) return workspace.tabs;
    const rank = new Map(pendingTabOrder.order.map((id, index) => [id, index]));
    return [...workspace.tabs].sort((left, right) =>
      (rank.get(left.id) ?? Number.MAX_SAFE_INTEGER) - (rank.get(right.id) ?? Number.MAX_SAFE_INTEGER));
  }

  function rememberWorkspaceDisclosure(key: string, event: Event) {
    const details = event.currentTarget;
    if (!(details instanceof HTMLDetailsElement)) return;
    workspaceDisclosure[key] = details.open;
  }

  function tabOrderingAvailable(workspace: WorkspaceGroup): boolean {
    const connection = connections.get(workspace.relayId);
    return Boolean(
      connection?.status === 'connected'
      && connection.inventory.state === 'ready'
      && connection.capabilities.includes('tab_reorder'),
    );
  }

  async function commitReorder(workspace: WorkspaceGroup, sourceTabId: string, insertIndex: number, order: string[]) {
    if (movingTab) return;
    const agent = displayTabs(workspace).find((tab) => tab.id === sourceTabId)?.agents[0];
    if (!agent) return;
    pendingTabOrder = { key: workspace.key, order };
    movingTab = sourceTabId;
    try {
      await relayStore.reorderTab(agent, insertIndex);
      relayStore.showToast('Tab order updated on Herdr.');
    } catch (error) {
      pendingTabOrder = null;
      relayStore.showToast((error as Error).message, true);
    } finally {
      movingTab = '';
    }
  }

  let suppressOpen = false;

  // Long-press a working agent card to lift its tab, drag to reorder, and
  // release to commit; a plain tap still opens the agent.
  function reorderPress(node: HTMLElement, params: { workspace?: WorkspaceGroup; tabId: string }) {
    let current = params;
    const hold = createReorderHold(node);
    let liftedOwner: { pointerId: number; pointerType: string } | null = null;

    function pointerIdentity(event: MouseEvent) {
      const { pointerId, pointerType } = event as PointerEvent;
      return Number.isInteger(pointerId) && pointerId > 0 && ['mouse', 'touch', 'pen'].includes(pointerType)
        ? { pointerId, pointerType } : null;
    }

    function clearOwnedDrag() {
      if (tabDrag?.owner === node) tabDrag = null;
    }

    function onPointerDown(event: PointerEvent) {
      if (hold.pointerId !== -1) return;
      liftedOwner = null;
      suppressOpen = false;
      const workspace = current.workspace;
      if (!workspace || !event.isPrimary || event.button !== 0 || movingTab) return;
      hold.start(event, () => {
        const items = measureTabSlots(node);
        if (items.length < 2) {
          hold.reset();
          return;
        }
        hold.lift(() => {
          liftedOwner = pointerIdentity(event);
          suppressOpen = true;
        });
        const sourceIdx = items.findIndex((item) => item.id === current.tabId);
        tabDrag = {
          owner: node,
          workspaceKey: workspace.key,
          sourceTabId: current.tabId,
          pointerId: hold.pointerId,
          startY: hold.startY + window.scrollY,
          deltaY: 0,
          insertIdx: Math.max(0, sourceIdx),
          items,
          gap: slotGap(items),
        };
      });
    }

    function onClick(event: MouseEvent) {
      // Identified overlaps cannot spend the owner's ticket or the legacy fallback.
      if (hold.pointerId === -1 && liftedOwner) {
        const identity = pointerIdentity(event);
        if (identity) {
          if (identity.pointerId === liftedOwner.pointerId && identity.pointerType === liftedOwner.pointerType) {
            liftedOwner = null;
            suppressOpen = false;
          }
          event.preventDefault();
          event.stopPropagation();
          return;
        }
      }
      // Zero-detail clicks can be keyboard or programmatic activation during a pending hold.
      if (!suppressOpen && (hold.pointerId === -1 || event.detail === 0)) return;
      // Keep a lifted owner's one-shot suppression until its pointer lifetime ends.
      if (hold.pointerId === -1) suppressOpen = false;
      event.preventDefault();
      event.stopPropagation();
    }

    const stopListening = hold.listen(onPointerDown, {
      move(event) {
        if (current.workspace) trackTabDrag(event, current.workspace);
      },
      finish(event) {
        if (current.workspace) finishTabDrag(event, current.workspace);
      },
      cancel: clearOwnedDrag,
    });
    node.addEventListener('click', onClick, true);
    return {
      update(next: { workspace?: WorkspaceGroup; tabId: string }) {
        current = next;
        if (!next.workspace) {
          clearOwnedDrag();
          hold.cancel();
        }
      },
      destroy() {
        liftedOwner = null;
        stopListening();
        node.removeEventListener('click', onClick, true);
        clearOwnedDrag();
        hold.destroy();
      },
    };
  }

  // Slots are captured in document coordinates when the drag starts, so the
  // preview stays correct while the page auto-scrolls under the pointer.
  function measureTabSlots(node: HTMLElement): ReorderSlot[] {
    const container = node.closest('.workspace-tabs');
    if (!container) return [];
    return [...container.querySelectorAll<HTMLElement>('.workspace-tab')].map((section) => {
      const bounds = section.getBoundingClientRect();
      return { id: section.dataset.tabId || '', top: bounds.top + window.scrollY, height: bounds.height };
    });
  }

  function trackTabDrag(event: PointerEvent, workspace: WorkspaceGroup) {
    if (!tabDrag || tabDrag.pointerId !== event.pointerId || tabDrag.workspaceKey !== workspace.key) return;
    event.preventDefault();
    if (event.clientY < 72) window.scrollBy(0, -12);
    else if (event.clientY > window.innerHeight - 72) window.scrollBy(0, 12);
    const pointerY = event.clientY + window.scrollY;
    const insertIdx = insertionSlot(tabDrag.items, tabDrag.sourceTabId, pointerY);
    tabDrag = { ...tabDrag, deltaY: pointerY - tabDrag.startY, insertIdx };
  }

  // The dragged tab follows the pointer; every other tab translates by the
  // dragged tab's height to preview the drop slot.
  function tabShift(workspace: WorkspaceGroup, tabId: string): string {
    if (!tabDrag || tabDrag.workspaceKey !== workspace.key) return '';
    if (tabId === tabDrag.sourceTabId) return `translateY(${tabDrag.deltaY}px)`;
    const { items, sourceTabId, insertIdx, gap } = tabDrag;
    return displacedSlot(items, sourceTabId, tabId, insertIdx, gap);
  }

  function finishTabDrag(event: PointerEvent, workspace: WorkspaceGroup) {
    if (!tabDrag || tabDrag.pointerId !== event.pointerId || tabDrag.workspaceKey !== workspace.key) return;
    const completed = tabDrag;
    tabDrag = null;
    const sourceIdx = completed.items.findIndex((item) => item.id === completed.sourceTabId);
    if (sourceIdx < 0 || completed.insertIdx === sourceIdx) return;
    const others = completed.items.filter((item) => item.id !== completed.sourceTabId);
    // Herdr's insert_index addresses the pre-move list and shifts the slot
    // down by one itself when the source sits before it.
    const insertIndex = completed.insertIdx >= others.length
      ? completed.items.length
      : completed.items.findIndex((item) => item.id === others[completed.insertIdx].id);
    const order = [
      ...others.slice(0, completed.insertIdx).map((item) => item.id),
      completed.sourceTabId,
      ...others.slice(completed.insertIdx).map((item) => item.id),
    ];
    void commitReorder(workspace, completed.sourceTabId, insertIndex, order);
  }


  function handleTabOrderKey(event: KeyboardEvent, workspace: WorkspaceGroup, tabId: string) {
    if (!event.altKey) return;
    const delta = event.key === 'ArrowUp' || event.key === 'ArrowLeft'
      ? -1
      : event.key === 'ArrowDown' || event.key === 'ArrowRight' ? 1 : 0;
    if (!delta || movingTab) return;
    const tabs = displayTabs(workspace);
    const index = tabs.findIndex((tab) => tab.id === tabId);
    if (index < 0 || !tabs[index + delta]) return;
    event.preventDefault();
    const insertIndex = delta > 0 ? index + 2 : index - 1;
    const order = tabs.map((tab) => tab.id);
    [order[index], order[index + delta]] = [order[index + delta], order[index]];
    void commitReorder(workspace, tabId, insertIndex, order);
  }

  // A lone single-choice question with a few plain options is answered from the card in one
  // tap; long questions, descriptions, multi-select, several questions or anything unexpected
  // keep the full form.
  function quickQuestion(interaction: QuestionInteraction): boolean {
    return interaction.kind === 'single_select' && interaction.options.length > 0
      && interaction.options.length <= 4 && (interaction.question_total ?? 1) <= 1 && interaction.submit_label !== 'Next'
      && interaction.question.length <= 400
      && interaction.options.every((option) => !option.description && !option.summary?.length);
  }

  async function quickAnswer(agent: Agent, interaction: QuestionInteraction, index: number) {
    let fresh: QuestionInteraction | undefined;
    try {
      const result = await relayStore.answerQuestion(agent, interaction, { selected: new Set([index]), otherSelected: false, otherText: '' });
      relayStore.clearResponding(agent.pane_id);
      if (result.phase === 'confirmed') {
        relayStore.applyQuestionInteraction(agent, null);
        relayStore.showToast('Answer sent.');
        return;
      }
      fresh = returnedInteraction(result);
      relayStore.showToast(...answerFailureToast({ message: 'Unexpected question result.' }, fresh, interaction));
    } catch (caught) {
      relayStore.clearResponding(agent.pane_id);
      // A follow-up question comes back as a failed answer that carries the new question.
      fresh = returnedInteraction(caught as CommandError);
      relayStore.showToast(...answerFailureToast(caught as CommandError, fresh, interaction));
    }
    if (fresh) relayStore.applyQuestionInteraction(agent, fresh);
  }

  async function respond(agent: Agent, index: number, total: number, option: string) {
    await relayStore.respond(agent, index, total, option);
  }

  function agentMeta(agent: Agent, compact: boolean): string {
    const tab = compact ? '' : tabName(agent);
    const labels = [
      tab && tab !== displayName(agent) ? tab : '',
      agent.session || '',
    ].filter(Boolean);
    if (agent.agent && !hasAgentLogo(agent.agent)) labels.push(agentDisplayName(agent.agent));
    return labels.join(' · ');
  }

  // Home-relative where the relay reported its home directory, absolute
  // otherwise: a row says which directory the agent runs in, not just its
  // last segment.
  function relayPath(relayId: string, path: string): string {
    return homeRelativePath(path, connections.get(relayId)?.home || '');
  }

  function relativeTimestamp(timestamp: number): string {
    if (!timestamp) return '';
    const seconds = Math.max(0, Math.floor((relativeNow - timestamp) / 1_000));
    if (seconds < 60) return 'now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days}d`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months}mo`;
    return `${Math.floor(months / 12)}y`;
  }

  function relativeAge(agent: Agent): string {
    return relativeTimestamp(agentLastActiveAt(agent));
  }

  onMount(() => {
    const timer = setInterval(() => { relativeNow = Date.now(); }, 60_000);
    return () => clearInterval(timer);
  });
</script>

<!-- Drawn rather than typed: the shipped Nerd Font is a terminal-sized
     download the home screen has no other reason to fetch. -->
{#snippet folderIcon()}
  <svg class="path-symbol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
    <path d="M3 5.5h7l2 2h9v11H3z"></path>
  </svg>
{/snippet}

{#snippet pathRow(path: string)}
  <small class="path-row">{@render folderIcon()}<span>{path}</span></small>
{/snippet}

{#snippet agentGrid(visible: Agent[], compact: boolean, reorderWorkspace?: WorkspaceGroup, reorderTabId?: string)}
  <div class:compact-agent-grid={compact} class="agent-grid">
    {#each visible as agent (agent.pane_id)}
      {@const interaction = questionInteraction(agent)}
      {@const options = approvalOptions(agent)}
      {@const group = agentStatusGroup(agent)}
      {@const tone = agentStatusTone(agent)}
      {@const blocked = group === 'blocked'}
      {@const needsInspection = group === 'attention'}
      {@const meta = agentMeta(agent, compact)}
      {@const age = relativeAge(agent)}
      {@const agentPath = compact ? relayPath(agent.relay_id, String(agent.cwd || '')) : ''}
      {@const inventoryReady = !connections.has(agent.relay_id) || connections.get(agent.relay_id)?.inventory.state === 'ready'}
      <article class:blocked class:compact-agent-card={compact} class:stale={!inventoryReady} class="agent-card">
        <button
          class="agent-open"
          aria-label={`Open ${displayName(agent)} on ${hostLabel(agent)}`}
          disabled={!inventoryReady}
          title={!inventoryReady
            ? 'This cached agent is unavailable until Herdr inventory recovers.'
            : reorderWorkspace ? 'Hold to reorder this tab; Alt+arrow keys also work.' : undefined}
          aria-keyshortcuts={reorderWorkspace ? 'Alt+ArrowUp Alt+ArrowDown' : undefined}
          use:reorderPress={{ workspace: reorderWorkspace, tabId: reorderTabId ?? '' }}
          onkeydown={reorderWorkspace ? (event) => handleTabOrderKey(event, reorderWorkspace, reorderTabId ?? '') : undefined}
          onclick={() => onopen(agent)}
        >
          <span class="agent-identity">
            <AgentLogo agent={agent.agent} />
            <span class={`status-dot status-${tone}`} aria-hidden="true"></span>
          </span>
          <span class="agent-copy">
            <span class="agent-title-row">
              {#if agentPath}
                <!-- Inside a workspace card the computer is named once, on the
                     card, so the row spends its width on the directory. -->
                <span class="agent-path">{@render folderIcon()}<span>{agentPath}</span></span>
              {:else}
                <span class="agent-project">{displayName(agent)}{#if !compact} <span class="host-badge">@{hostLabel(agent)}</span>{/if}</span>
              {/if}
              {#if compact && age}
                <time class="agent-age" datetime={new Date(agentLastActiveAt(agent)).toISOString()} title={new Date(agentLastActiveAt(agent)).toLocaleString()}>{age}</time>
              {/if}
            </span>
            {#if meta}<span class="agent-meta">{meta}</span>{/if}
            {#if blocked || needsInspection}
              <span class="prompt-preview" class:prompt-full={interaction && quickQuestion(interaction)}>{interaction?.question || approvalPromptPreview(agent)}</span>
            {/if}
          </span>
        </button>
        {#if blocked && !responding.has(agent.pane_id)}
          <div class="agent-actions" aria-label={`Actions for ${displayName(agent)}`}>
            {#if interaction && quickQuestion(interaction)}
              {#each interaction.options as option, position (`${interaction.id}:${option.index ?? position}`)}
                <Button
                  size="sm"
                  disabled={!inventoryReady}
                  title={!inventoryReady ? 'Agent controls are unavailable until Herdr inventory recovers.' : undefined}
                  onclick={() => quickAnswer(agent, interaction, Number.isInteger(option.index) ? option.index : position)}
                >{option.label}</Button>
              {/each}
              <Button variant="secondary" size="sm" onclick={() => onopen(agent)}>More…</Button>
            {:else if interaction}
              <Button variant="trust" size="sm" onclick={() => onopen(agent)}>
                {interaction.kind === 'multi_select' ? 'Choose options' : 'Choose answer'} ({interaction.options.length})
              </Button>
            {:else}
              {#each options as option, index (`${index}:${option}`)}
                <Button
                  variant={approvalButtonTone(option, index, options.length) === 'deny' ? 'danger' : approvalButtonTone(option, index, options.length) === 'trust' ? 'trust' : 'default'}
                  size="sm"
                  disabled={!inventoryReady}
                  title={!inventoryReady ? 'Agent controls are unavailable until Herdr inventory recovers.' : undefined}
                  onclick={() => respond(agent, index, options.length, option)}
                >{option}</Button>
              {/each}
            {/if}
          </div>
        {:else if blocked}
          <p class="responding" role="status">Waiting for agent…</p>
        {/if}
      </article>
    {/each}
  </div>
{/snippet}

{#snippet workspaceTabs(workspace: WorkspaceGroup)}
  <div class="workspace-tabs">
    {#each displayTabs(workspace) as tab (tab.id)}
      <section
        class:tab-dragging={tabDrag?.workspaceKey === workspace.key && tabDrag.sourceTabId === tab.id}
        class="workspace-tab"
        data-tab-id={tab.id}
        aria-label={`${tab.label} tab`}
        style:transform={tabShift(workspace, tab.id) || undefined}
      >
        <header class="workspace-tab-header">
          <h3>{tab.label}</h3>
        </header>
        {@render agentGrid(
          tab.agents,
          true,
          workspace.tabs.length > 1 && tabOrderingAvailable(workspace) ? workspace : undefined,
          tab.id,
        )}
      </section>
    {/each}
  </div>
  {#if !workspace.tabs.length}
    <p class="workspace-empty">No agents are running in this workspace.</p>
  {/if}
{/snippet}

{#snippet workspaceGrid(trees: WorkspaceGroupTree[], defaultOpen: boolean, kind: 'working' | 'done' | 'idle' | 'mixed')}
  <div class="workspace-grid">
    {#each trees as tree (tree.workspace.key)}
      {@const workspace = tree.workspace}
      {@const summary = tree.aggregate}
      {@const working = kind === 'working'}
      {@const done = kind === 'done'}
      {@const stateTone = kind === 'mixed' ? workspaceStateTone(summary) : ''}
      {@const provenance = workspaceProvenance(workspace)}
      {@const disclosureKey = `${working ? 'working' : done ? 'done' : 'workspace'}:${workspace.key}`}
      <!-- Mixed mirrors the state sections' opening rules: workspaces with a
           working or done session start expanded, idle-only cards collapsed. -->
      {@const openDefault = kind === 'mixed'
        ? defaultOpen || summary.workingCount > 0 || summary.doneCount > 0
        : defaultOpen}
      <details
        class:working-workspace-card={working}
        class:done-workspace-card={done}
        class="workspace-card"
        open={workspaceDisclosure[disclosureKey] ?? openDefault}
        ontoggle={(event) => rememberWorkspaceDisclosure(disclosureKey, event)}
      >
        <summary>
          {#if stateTone}
            <span
              class={`status-dot workspace-state-dot status-${stateTone}`}
              class:hollow={stateTone === 'muted'}
              role="img"
              aria-label={stateTone === 'success'
                ? 'Has a done session'
                : stateTone === 'warning'
                  ? 'Has a working session'
                  : stateTone === 'ready' ? 'All sessions idle and ready for input' : 'No session state reported'}
            ></span>
          {/if}
          <span class="workspace-card-copy">
            <span class="workspace-card-title">
              <strong>{workspace.label}</strong>
              {#if workspace.host}<span class="host-badge">@{workspace.host}</span>{/if}
            </span>
            {#if workspace.cwd}{@render pathRow(relayPath(workspace.relayId, workspace.cwd))}{/if}
          </span>
          <span
            class="workspace-counts"
            aria-label={`${summary.tabCount} tabs, ${summary.paneCount} panes, and ${summary.agents.length} agents`}
          >
            {#if working}<em class="workspace-working-count">{summary.workingCount} working</em>{/if}
            {#if done}<em class="workspace-done-count">{summary.doneCount} done</em>{/if}
            <span>{summary.tabCount} {summary.tabCount === 1 ? 'tab' : 'tabs'}</span>
            {#if tree.children.length}<span>{tree.children.length} {tree.children.length === 1 ? 'worktree' : 'worktrees'}</span>{/if}
            {#if !working && !done}<span>{summary.agents.length} {summary.agents.length === 1 ? 'agent' : 'agents'}</span>{/if}
            {#if summary.lastActiveAt}
              <time
                datetime={new Date(summary.lastActiveAt).toISOString()}
                title={`Last agent activity: ${new Date(summary.lastActiveAt).toLocaleString()}`}
                aria-label={`Last agent activity ${new Date(summary.lastActiveAt).toLocaleString()}`}
              >{relativeTimestamp(summary.lastActiveAt)}</time>
            {/if}
          </span>
        </summary>
        {#if provenance}
          <p class="workspace-provenance">{provenance}</p>
        {/if}
        {@render workspaceTabs(workspace)}
        {#if tree.children.length}
          <div class="workspace-worktree-list" role="group" aria-label={`${workspace.label} worktrees`}>
            {#each tree.children as child (child.key)}
              {@const childPath = informativePath(relayPath(child.relayId, child.cwd), child.label)}
              <section class="workspace-worktree-card" aria-label={`${child.label} worktree`}>
                <header>
                  <span>
                    <strong>{child.label}</strong>
                    {#if childPath}{@render pathRow(childPath)}{/if}
                  </span>
                  <span>{child.tabCount} {child.tabCount === 1 ? 'tab' : 'tabs'}</span>
                </header>
                {@render workspaceTabs(child)}
              </section>
            {/each}
          </div>
        {/if}
      </details>
    {/each}
  </div>
{/snippet}

<main class="agent-list" aria-label="Agents">
  {#if serverFilterVisible}
    <div class="server-filters" role="group" aria-label="Show servers">
      {#each allRelays as relay (relay.id)}
        {@const waiting = hiddenNeedsAttention(relay.id)}
        <Button
          variant="secondary"
          aria-pressed={!hidden.includes(relay.id)}
          onclick={() => setServerHidden(relay.id, !hidden.includes(relay.id))}
        >{serverFilterLabel(relay)}{#if waiting}<span class="section-count" role="img" aria-label={`${waiting} need attention while hidden`}>{waiting}</span>{/if}</Button>
      {/each}
    </div>
  {/if}
  {#each unavailableRelays as relay (relay.id)}
    {@const inventory = connections.get(relay.id)?.inventory}
    <section class="inventory-warning" role="status" aria-label={`${relay.label} agent inventory unavailable`}>
      <strong>{relay.label} is connected, but its Herdr agent inventory is unavailable.</strong>
      <span>{inventory?.message || 'Refresh after checking Herdr on that computer.'}</span>
      {#if inventory?.stale}<span>Previously reported agents are shown as stale.</span>{/if}
    </section>
  {/each}

  {#if serverFilterVisible && !relays.length}
    <div class="empty-state" role="status">All servers are hidden.</div>
  {:else if !agents.length && !relays.length}
    <div class="empty-state">
      <span class="empty-icon" aria-hidden="true">🐑</span>
      <h2>Herdr Mobile Relay</h2>
      <p>Monitor and approve agents from your phone.</p>
      <ol>
        <li>Run a relay on each computer.</li>
        <li>Give each computer its own <code>wss://</code> URL.</li>
        <li>Open Settings and add each relay.</li>
      </ol>
    </div>
  {:else if !agents.length && startingRelays.length}
    <div class="empty-state" role="status">Loading agents…</div>
  {:else if !agents.length && readyRelays.length}
    <div class="empty-state" role="status">No chat agents are running.</div>
  {:else if !agents.length && deferredRelays.length === relays.length}
    <div class="empty-state" role="status">
      <p>Add Herdr to the Home Screen, then open it there to finish pairing.</p>
      <p>This browser tab keeps the setup link unused so the installed app can redeem it.</p>
      {#each deferredRelays as relay (relay.id)}
        <div role="group" aria-label={relay.label}>
          <PairDeferredRelay relayId={relay.id} onPair={(id) => relayStore.pairDeferredRelay(id)} />
        </div>
      {/each}
    </div>
  {:else if !agents.length && !unavailableRelays.length}
    <div class="empty-state" role="status">Waiting for relays…</div>
  {/if}

  {#each statusDefinitions as [group, title, tone] (group)}
    {@const visible = sortedAgents(agents.filter((agent) => agentStatusGroup(agent) === group))}
    {#if visible.length}
      <section class="agent-section" aria-labelledby={`section-${group}`}>
        <h2 id={`section-${group}`} class="section-heading">
          <span class={`status-dot status-${tone}`}></span>{title}
          <span class="section-count" aria-hidden="true">{visible.length}</span>
        </h2>
        {@render agentGrid(visible, false)}
      </section>
    {/if}
  {/each}

  {#if doneWorkspaces.length}
    <section class="agent-section done-section" aria-labelledby="section-done">
      <h2 id="section-done" class="section-heading">
        <span class="status-dot status-success"></span>Done
        <span class="section-count" aria-hidden="true">{doneAgents.length}</span>
      </h2>
      {@render workspaceGrid(doneWorkspaces, true, 'done')}
    </section>
  {/if}

  {#if workingWorkspaces.length}
    <section class="agent-section working-section" aria-labelledby="section-working">
      <h2 id="section-working" class="section-heading">
        <span class="status-dot status-warning"></span>Working
        <span class="section-count" aria-hidden="true">{workingAgents.length}</span>
      </h2>
      {@render workspaceGrid(workingWorkspaces, true, 'working')}
    </section>
  {/if}

  {#if idleWorkspaces.length}
    <section class="agent-section workspace-section" aria-labelledby="workspace-section-title">
      <h2 id="workspace-section-title" class="section-heading">
        <span class="status-dot status-ready"></span>Idle
        <span class="section-count" aria-hidden="true">{idleWorkspaces.length}</span>
      </h2>
      {@render workspaceGrid(idleWorkspaces, idleWorkspaces.length === 1, 'idle')}
    </section>
  {/if}

  {#if mixedWorkspaces.length}
    <!-- No visible heading: the per-card state dots already tell the story. -->
    <section class="agent-section workspace-section" aria-label="Workspaces">
      {@render workspaceGrid(mixedWorkspaces, mixedWorkspaces.length === 1, 'mixed')}
    </section>
  {/if}
</main>
